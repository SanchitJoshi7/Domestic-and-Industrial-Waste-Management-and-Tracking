# Waste Management & Pollution Monitoring Dashboard

## Quick Start

### 1. Configure your environment
```bash
cp database/.env.example database/.env
# Open database/.env and set your SECRET_KEY and JWT_SECRET_KEY
```

### 2. Install dependencies
```bash
cd backend
pip install -r requirements.txt
```

### 3. Start the backend
```bash
python run.py
```
The server starts at **http://localhost:5000**. Keep this terminal open.

### 4. Open the frontend
Open `frontend/index.html` in your browser and register an account.

---

## What was fixed

| File | Problem | Fix |
|------|---------|-----|
| `routes/domestic.py` | Standalone Flask app, not a Blueprint | Rewritten as `domestic_bp` Blueprint |
| `routes/pollution.py` | Standalone Flask app, not a Blueprint | Rewritten as `pollution_bp` Blueprint |
| `routes/alerts.py` | Standalone Flask app, not a Blueprint | Rewritten as `alerts_bp` Blueprint |
| `routes/industrial.py` | Standalone Flask app, not a Blueprint | Rewritten as `industrial_bp` Blueprint |

The original files created `app = Flask(__name__)` inside each route file. When `app.py` tried to import them as Blueprints, Python crashed immediately — causing the terminal window to flash and close.

---

## Project structure

```
waste_dashboard_fixed/
├── database/
│   ├── .env            ← your secrets (never commit this)
│   └── .env.example    ← template to copy from
├── backend/
│   ├── run.py          ← START HERE: python run.py
│   ├── app.py          ← Flask app factory
│   ├── config.py       ← loads database/.env automatically
│   ├── requirements.txt
│   ├── models/         ← SQLAlchemy models (User, Alert, etc.)
│   └── routes/         ← All route Blueprints
└── frontend/
    ├── index.html
    ├── js/
    └── styles/
```

---

## Switching databases

Edit `DATABASE_URL` in `database/.env`:

- **SQLite** (default, no setup): `DATABASE_URL=sqlite:///ecowatch.db`
- **PostgreSQL** (production): `DATABASE_URL=postgresql://user:password@localhost:5432/dbname`
