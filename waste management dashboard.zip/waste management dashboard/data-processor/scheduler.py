"""
scheduler.py
============
Drives the data-processor pipeline on a configurable cron/interval schedule
using APScheduler (lightweight, no external broker required).

Jobs
----
- poll_csvs        : scan data/ for new CSVs and run the full pipeline
- health_check     : ping the backend /health endpoint and log status
- purge_old_logs   : delete run-log JSON files older than LOG_RETENTION_DAYS

Usage
-----
    python scheduler.py                       # start with defaults
    python scheduler.py --interval 120        # poll every 120 seconds
    python scheduler.py --once                # single run, then exit
    python scheduler.py --cron "0 * * * *"   # every hour on the hour
"""

from __future__ import annotations

import argparse
import logging
import os
import signal
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

import requests

logger = logging.getLogger("data_processor.scheduler")

# ---------------------------------------------------------------------------
# Configuration (env-var overrides)
# ---------------------------------------------------------------------------

POLL_INTERVAL_SECONDS = int(os.environ.get("POLL_INTERVAL_SECONDS", "60"))
LOG_RETENTION_DAYS    = int(os.environ.get("LOG_RETENTION_DAYS",    "7"))
BACKEND_HEALTH_URL    = os.environ.get(
    "BACKEND_HEALTH_URL", "http://localhost:5000/health"
)
DATA_DIR    = os.environ.get("DATA_DIR",    "data")
OUTPUT_DIR  = os.environ.get("OUTPUT_DIR",  "data/processed")
ERROR_DIR   = os.environ.get("ERROR_DIR",   "data/errors")
LOG_DIR     = os.environ.get("LOG_DIR",     "logs")
BACKEND_URL = os.environ.get("BACKEND_INGEST_URL", "http://localhost:5000/sensors/ingest")
DRY_RUN     = os.environ.get("DRY_RUN", "false").lower() == "true"


# ---------------------------------------------------------------------------
# Job functions (plain functions – called by the loop or APScheduler)
# ---------------------------------------------------------------------------

def job_poll_csvs() -> None:
    """Scan data/ for CSVs and run the processing pipeline."""
    from sensor_processor import SensorProcessor

    logger.info("[job_poll_csvs] Starting pipeline run …")
    try:
        processor = SensorProcessor(
            data_dir=DATA_DIR,
            output_dir=OUTPUT_DIR,
            error_dir=ERROR_DIR,
            log_dir=LOG_DIR,
            backend_url=BACKEND_URL,
            dry_run=DRY_RUN,
        )
        run = processor.run_batch()
        s = run.summary()
        logger.info(
            "[job_poll_csvs] Done — read=%d valid=%d invalid=%d ingested=%d (%.1fs)",
            s["total_read"], s["total_valid"], s["total_invalid"],
            s["total_ingested"], s.get("duration_s") or 0,
        )
    except Exception as exc:
        logger.exception("[job_poll_csvs] Unhandled error: %s", exc)


def job_health_check() -> None:
    """Ping the backend health endpoint and log the result."""
    try:
        resp = requests.get(BACKEND_HEALTH_URL, timeout=5)
        if resp.status_code == 200:
            logger.info("[job_health_check] Backend OK → %s", resp.json())
        else:
            logger.warning(
                "[job_health_check] Backend returned HTTP %d", resp.status_code
            )
    except requests.RequestException as exc:
        logger.error("[job_health_check] Backend unreachable: %s", exc)


def job_purge_old_logs(log_dir: str = LOG_DIR, retention_days: int = LOG_RETENTION_DAYS) -> None:
    """Delete JSON run-logs older than *retention_days*."""
    cutoff = datetime.utcnow() - timedelta(days=retention_days)
    log_path = Path(log_dir)
    if not log_path.exists():
        return

    deleted = 0
    for f in log_path.glob("run_*.json"):
        try:
            mtime = datetime.utcfromtimestamp(f.stat().st_mtime)
            if mtime < cutoff:
                f.unlink()
                deleted += 1
        except OSError:
            pass

    if deleted:
        logger.info("[job_purge_old_logs] Deleted %d old log file(s)", deleted)


# ---------------------------------------------------------------------------
# Scheduler implementations
# ---------------------------------------------------------------------------

class SimpleIntervalScheduler:
    """
    Pure-Python fallback scheduler (no external dependencies).
    Runs jobs in a blocking loop at a fixed interval.
    """

    def __init__(self, interval_seconds: int = POLL_INTERVAL_SECONDS) -> None:
        self.interval = interval_seconds
        self._running = False
        self._jobs: list[tuple[str, callable, int, int]] = []
        # (name, fn, every_N_ticks, tick_counter)

    def add_job(self, name: str, fn: callable, every_ticks: int = 1) -> None:
        """Register a job.  every_ticks=1 means run every interval tick."""
        self._jobs.append([name, fn, every_ticks, 0])

    def start(self, run_immediately: bool = True) -> None:
        self._running = True
        logger.info(
            "SimpleIntervalScheduler started — interval=%ds, jobs=%d",
            self.interval, len(self._jobs),
        )
        signal.signal(signal.SIGINT,  self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

        if run_immediately:
            self._tick()

        while self._running:
            time.sleep(self.interval)
            if self._running:
                self._tick()

        logger.info("Scheduler stopped.")

    def stop(self) -> None:
        self._running = False

    def _tick(self) -> None:
        for job in self._jobs:
            name, fn, every, counter = job
            job[3] = counter + 1
            if job[3] % every == 0:
                logger.debug("Running job: %s", name)
                try:
                    fn()
                except Exception as exc:
                    logger.exception("Job '%s' raised an error: %s", name, exc)

    def _handle_signal(self, signum, _frame) -> None:
        logger.info("Received signal %s — shutting down …", signum)
        self.stop()


class APSchedulerRunner:
    """
    Scheduler backed by APScheduler (if installed).
    Supports cron expressions in addition to fixed intervals.
    """

    def __init__(self) -> None:
        try:
            from apscheduler.schedulers.blocking import BlockingScheduler
            self._scheduler = BlockingScheduler(timezone="UTC")
            self._available = True
        except ImportError:
            logger.warning(
                "APScheduler not installed — falling back to SimpleIntervalScheduler. "
                "Install it with: pip install apscheduler"
            )
            self._available = False

    @property
    def available(self) -> bool:
        return self._available

    def add_interval_job(
        self, fn: callable, seconds: int, job_id: str | None = None
    ) -> None:
        if not self._available:
            raise RuntimeError("APScheduler not available")
        self._scheduler.add_job(fn, "interval", seconds=seconds, id=job_id or fn.__name__)

    def add_cron_job(self, fn: callable, cron_expr: str, job_id: str | None = None) -> None:
        """
        Add a job with a standard 5-field cron expression, e.g. "*/5 * * * *".
        """
        if not self._available:
            raise RuntimeError("APScheduler not available")
        from apscheduler.triggers.cron import CronTrigger
        trigger = CronTrigger.from_crontab(cron_expr, timezone="UTC")
        self._scheduler.add_job(fn, trigger, id=job_id or fn.__name__)

    def start(self) -> None:
        if not self._available:
            raise RuntimeError("APScheduler not available")
        logger.info("APScheduler started.")
        self._scheduler.start()

    def stop(self) -> None:
        if self._available:
            self._scheduler.shutdown(wait=False)


# ---------------------------------------------------------------------------
# Factory / entry-point
# ---------------------------------------------------------------------------

def build_and_start(
    interval: int = POLL_INTERVAL_SECONDS,
    cron: str | None = None,
    once: bool = False,
    use_apscheduler: bool = True,
) -> None:
    """Configure and start the scheduler."""

    if once:
        logger.info("--once flag set: running pipeline once then exiting.")
        job_health_check()
        job_poll_csvs()
        job_purge_old_logs()
        return

    ap = APSchedulerRunner() if use_apscheduler else None

    if ap and ap.available:
        if cron:
            ap.add_cron_job(job_poll_csvs, cron, job_id="poll_csvs")
        else:
            ap.add_interval_job(job_poll_csvs, seconds=interval, job_id="poll_csvs")

        # Health check every 5 minutes
        ap.add_interval_job(job_health_check, seconds=300, job_id="health_check")

        # Log purge once per day (86 400 s)
        ap.add_interval_job(job_purge_old_logs, seconds=86_400, job_id="purge_logs")

        ap.start()
    else:
        # Fallback to simple scheduler (ignores cron expression)
        scheduler = SimpleIntervalScheduler(interval_seconds=interval)
        scheduler.add_job("poll_csvs",    job_poll_csvs,    every_ticks=1)
        scheduler.add_job("health_check", job_health_check, every_ticks=max(1, 300 // interval))
        scheduler.add_job("purge_logs",   job_purge_old_logs, every_ticks=max(1, 86_400 // interval))
        scheduler.start()


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(Path(LOG_DIR) / "scheduler.log"),
        ],
    )

    parser = argparse.ArgumentParser(description="EcoWatch Data Processor Scheduler")
    parser.add_argument(
        "--interval", type=int, default=POLL_INTERVAL_SECONDS,
        help="Polling interval in seconds (default: %(default)s)",
    )
    parser.add_argument(
        "--cron", type=str, default=None,
        help='Cron expression for APScheduler, e.g. "*/5 * * * *"',
    )
    parser.add_argument(
        "--once", action="store_true",
        help="Run the pipeline once then exit",
    )
    parser.add_argument(
        "--no-apscheduler", action="store_true",
        help="Force the simple built-in scheduler even if APScheduler is installed",
    )
    args = parser.parse_args()

    build_and_start(
        interval=args.interval,
        cron=args.cron,
        once=args.once,
        use_apscheduler=not args.no_apscheduler,
    )
