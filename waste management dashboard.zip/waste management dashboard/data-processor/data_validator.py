"""
data_validator.py
=================
Validates raw sensor readings against configured environmental thresholds and
schema rules before they are persisted or forwarded to the backend API.

Responsibilities
----------------
- Schema validation  : required fields, correct dtypes, value ranges
- Threshold checks   : flag readings that breach WHO / CPCB limits
- Anomaly detection  : z-score spike detection against a rolling window
- Result reporting   : structured ValidationResult objects used by the pipeline
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

logger = logging.getLogger("data_processor.validator")

# ---------------------------------------------------------------------------
# Threshold definitions (WHO / CPCB / standard limits)
# ---------------------------------------------------------------------------

# (min_valid, max_valid, warning_threshold, critical_threshold)
SENSOR_THRESHOLDS: dict[str, dict[str, tuple[float, float, float, float]]] = {
    "air_quality": {
        "pm25":        (0.0,   999.0,  60.0,  120.0),   # µg/m³
        "pm10":        (0.0,  1999.0, 100.0,  250.0),   # µg/m³
        "no2":         (0.0,   999.0,  80.0,  200.0),   # ppb
        "so2":         (0.0,   999.0, 100.0,  300.0),   # ppb
        "co":          (0.0,    50.0,   4.0,   10.0),   # ppm
        "aqi":         (0.0,   500.0, 200.0,  300.0),
    },
    "water_quality": {
        "bod":         (0.0,   500.0,  30.0,  100.0),   # mg/L
        "cod":         (0.0,  2000.0, 250.0,  500.0),   # mg/L
        "ph":          (0.0,    14.0,   6.0,    9.0),   # pH units (warning outside 6-9)
        "toc":         (0.0,   500.0,  20.0,   50.0),   # mg/L
    },
    "temperature": {
        "temperature": (-50.0, 80.0,  40.0,   50.0),   # °C
    },
    "humidity": {
        "humidity":    (0.0,  100.0,  90.0,   98.0),   # %
    },
    "noise": {
        "noise_db":    (0.0,  200.0,  70.0,   90.0),   # dB
    },
}

# Required fields for every reading regardless of type
BASE_REQUIRED_FIELDS: list[str] = ["sensor_id", "sensor_type", "recorded_at"]

VALID_SENSOR_TYPES: set[str] = set(SENSOR_THRESHOLDS.keys())

# ---------------------------------------------------------------------------
# Result data-classes
# ---------------------------------------------------------------------------

@dataclass
class FieldIssue:
    field: str
    severity: str          # "error" | "warning" | "info"
    message: str
    value: Any = None


@dataclass
class ValidationResult:
    sensor_id: str
    sensor_type: str
    recorded_at: str | None
    is_valid: bool                         # False → record should be rejected
    has_warnings: bool                     # True → record accepted but flagged
    issues: list[FieldIssue] = field(default_factory=list)
    cleaned_record: dict | None = None     # coerced / cleaned version

    # Convenience
    @property
    def errors(self) -> list[FieldIssue]:
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self) -> list[FieldIssue]:
        return [i for i in self.issues if i.severity == "warning"]

    def to_dict(self) -> dict:
        return {
            "sensor_id":   self.sensor_id,
            "sensor_type": self.sensor_type,
            "recorded_at": self.recorded_at,
            "is_valid":    self.is_valid,
            "has_warnings": self.has_warnings,
            "issues": [
                {"field": i.field, "severity": i.severity,
                 "message": i.message, "value": i.value}
                for i in self.issues
            ],
        }


# ---------------------------------------------------------------------------
# Rolling window for anomaly detection (in-memory, per sensor_id+field)
# ---------------------------------------------------------------------------

class _RollingStats:
    """Welford's online mean/variance for spike detection."""

    def __init__(self, window: int = 20) -> None:
        self._window = window
        self._values: list[float] = []

    def push(self, value: float) -> None:
        self._values.append(value)
        if len(self._values) > self._window:
            self._values.pop(0)

    def zscore(self, value: float) -> float | None:
        if len(self._values) < 5:
            return None
        mean = sum(self._values) / len(self._values)
        variance = sum((v - mean) ** 2 for v in self._values) / len(self._values)
        std = math.sqrt(variance)
        if std == 0:
            return None
        return abs((value - mean) / std)


_rolling_stats: dict[str, _RollingStats] = {}


def _stats_key(sensor_id: str, field_name: str) -> str:
    return f"{sensor_id}::{field_name}"


# ---------------------------------------------------------------------------
# Main validator
# ---------------------------------------------------------------------------

class DataValidator:
    """
    Stateless-style validator; rolling-window state is module-level so it
    persists across calls within the same process.
    """

    ZSCORE_WARNING  = 3.0
    ZSCORE_CRITICAL = 5.0

    def validate(self, record: dict) -> ValidationResult:
        """Validate a single sensor reading dict. Returns a ValidationResult."""
        issues: list[FieldIssue] = []

        # --- 1. Base schema ---
        sensor_id   = str(record.get("sensor_id", "")).strip()
        sensor_type = str(record.get("sensor_type", "")).strip().lower()
        recorded_at = record.get("recorded_at")

        if not sensor_id:
            issues.append(FieldIssue("sensor_id", "error", "sensor_id is required"))
        if not sensor_type:
            issues.append(FieldIssue("sensor_type", "error", "sensor_type is required"))
        elif sensor_type not in VALID_SENSOR_TYPES:
            issues.append(FieldIssue(
                "sensor_type", "error",
                f"Unknown sensor_type '{sensor_type}'. "
                f"Must be one of: {sorted(VALID_SENSOR_TYPES)}",
                sensor_type,
            ))

        if recorded_at is None:
            issues.append(FieldIssue("recorded_at", "error", "recorded_at is required"))
        else:
            recorded_at = self._parse_timestamp(recorded_at, issues)

        # Bail early on fatal schema errors
        if any(i.severity == "error" for i in issues):
            return ValidationResult(
                sensor_id=sensor_id or "unknown",
                sensor_type=sensor_type or "unknown",
                recorded_at=str(recorded_at) if recorded_at else None,
                is_valid=False,
                has_warnings=False,
                issues=issues,
            )

        # --- 2. Numeric coercion & range checks ---
        cleaned = dict(record)
        thresholds = SENSOR_THRESHOLDS.get(sensor_type, {})

        for field_name, (v_min, v_max, warn_thresh, crit_thresh) in thresholds.items():
            raw = record.get(field_name)
            if raw is None:
                # Not every sensor reports every field – that is fine
                continue

            coerced = self._to_float(raw, field_name, issues)
            if coerced is None:
                continue

            cleaned[field_name] = coerced

            # Hard range check (instrument error / garbage data)
            if not (v_min <= coerced <= v_max):
                issues.append(FieldIssue(
                    field_name, "error",
                    f"Value {coerced} out of valid instrument range "
                    f"[{v_min}, {v_max}]",
                    coerced,
                ))
                continue

            # Environmental threshold breach
            severity = self._threshold_severity(
                field_name, coerced, warn_thresh, crit_thresh, sensor_type
            )
            if severity:
                issues.append(FieldIssue(
                    field_name, severity,
                    f"Value {coerced} breaches {'critical' if severity == 'error' else 'warning'} "
                    f"threshold ({crit_thresh if severity == 'error' else warn_thresh})",
                    coerced,
                ))

            # Anomaly / spike detection
            self._check_anomaly(sensor_id, field_name, coerced, issues)

        # --- 3. Coordinate sanity ---
        lat = self._to_float(record.get("latitude"), "latitude", [])
        lon = self._to_float(record.get("longitude"), "longitude", [])
        if lat is not None and not (-90 <= lat <= 90):
            issues.append(FieldIssue("latitude", "error", f"Latitude {lat} out of range [-90, 90]", lat))
        if lon is not None and not (-180 <= lon <= 180):
            issues.append(FieldIssue("longitude", "error", f"Longitude {lon} out of range [-180, 180]", lon))

        # --- 4. Result ---
        has_errors   = any(i.severity == "error"   for i in issues)
        has_warnings = any(i.severity == "warning" for i in issues)

        return ValidationResult(
            sensor_id=sensor_id,
            sensor_type=sensor_type,
            recorded_at=str(recorded_at) if recorded_at else None,
            is_valid=not has_errors,
            has_warnings=has_warnings,
            issues=issues,
            cleaned_record=cleaned if not has_errors else None,
        )

    def validate_batch(self, records: list[dict]) -> list[ValidationResult]:
        """Validate a list of records and return results in the same order."""
        return [self.validate(r) for r in records]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_timestamp(
        value: Any, issues: list[FieldIssue]
    ) -> datetime | None:
        if isinstance(value, datetime):
            return value
        try:
            return datetime.fromisoformat(str(value))
        except (ValueError, TypeError):
            issues.append(FieldIssue(
                "recorded_at", "error",
                f"Cannot parse timestamp '{value}'. Expected ISO-8601.", value
            ))
            return None

    @staticmethod
    def _to_float(
        value: Any, field_name: str, issues: list[FieldIssue]
    ) -> float | None:
        if value is None:
            return None
        try:
            f = float(value)
            if math.isnan(f) or math.isinf(f):
                raise ValueError("NaN/Inf")
            return f
        except (ValueError, TypeError):
            issues.append(FieldIssue(
                field_name, "error",
                f"Non-numeric value '{value}' for field '{field_name}'", value
            ))
            return None

    @staticmethod
    def _threshold_severity(
        field_name: str,
        value: float,
        warn: float,
        crit: float,
        sensor_type: str,
    ) -> str | None:
        # pH is a range check (good between warn and crit)
        if field_name == "ph":
            if value < warn or value > crit:
                return "warning"
            return None
        # All other fields: higher = worse
        if value >= crit:
            return "error"
        if value >= warn:
            return "warning"
        return None

    @staticmethod
    def _check_anomaly(
        sensor_id: str,
        field_name: str,
        value: float,
        issues: list[FieldIssue],
    ) -> None:
        key = _stats_key(sensor_id, field_name)
        if key not in _rolling_stats:
            _rolling_stats[key] = _RollingStats()

        stats = _rolling_stats[key]
        z = stats.zscore(value)
        stats.push(value)   # update after computing to avoid self-influence

        if z is None:
            return
        if z >= DataValidator.ZSCORE_CRITICAL:
            issues.append(FieldIssue(
                field_name, "warning",
                f"Spike detected: z-score={z:.2f} (critical threshold={DataValidator.ZSCORE_CRITICAL})",
                value,
            ))
        elif z >= DataValidator.ZSCORE_WARNING:
            issues.append(FieldIssue(
                field_name, "info",
                f"Mild anomaly: z-score={z:.2f} (warning threshold={DataValidator.ZSCORE_WARNING})",
                value,
            ))


# Module-level singleton for convenience
default_validator = DataValidator()
