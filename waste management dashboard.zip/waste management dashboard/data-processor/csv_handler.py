"""
csv_handler.py
==============
Handles all CSV I/O for the data-processor pipeline.

Responsibilities
----------------
- Read raw sensor CSVs (single file or directory glob)
- Normalise column names and map legacy headers to canonical field names
- Chunk large files to avoid OOM on constrained devices
- Write processed / validated records back to CSV
- Maintain an error-row sidecar file alongside each output
"""

from __future__ import annotations

import csv
import io
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Generator, Iterable

logger = logging.getLogger("data_processor.csv_handler")

# ---------------------------------------------------------------------------
# Column-name normalisation map
# Legacy headers → canonical field names used by SensorData model
# ---------------------------------------------------------------------------

COLUMN_MAP: dict[str, str] = {
    # Identifiers
    "sensor":           "sensor_id",
    "id":               "sensor_id",
    "device_id":        "sensor_id",
    "type":             "sensor_type",
    "kind":             "sensor_type",

    # Timestamps
    "timestamp":        "recorded_at",
    "datetime":         "recorded_at",
    "date_time":        "recorded_at",
    "time":             "recorded_at",
    "date":             "recorded_at",

    # Location
    "lat":              "latitude",
    "lng":              "longitude",
    "lon":              "longitude",
    "long":             "longitude",
    "area":             "zone",
    "region":           "zone",
    "location":         "zone",

    # Air quality
    "pm2.5":            "pm25",
    "pm_2_5":           "pm25",
    "particulate_25":   "pm25",
    "pm_10":            "pm10",
    "particulate_10":   "pm10",
    "nitrogen_dioxide": "no2",
    "sulfur_dioxide":   "so2",
    "carbon_monoxide":  "co",
    "air_quality_index": "aqi",

    # Water quality
    "biochemical_oxygen_demand": "bod",
    "chemical_oxygen_demand":    "cod",
    "total_organic_carbon":      "toc",

    # Environment
    "temp":             "temperature",
    "temp_c":           "temperature",
    "rh":               "humidity",
    "relative_humidity": "humidity",
}


def _normalise_header(name: str) -> str:
    """Lower-case, strip spaces/hyphens, then look up alias map."""
    cleaned = name.strip().lower().replace(" ", "_").replace("-", "_")
    return COLUMN_MAP.get(cleaned, cleaned)


# ---------------------------------------------------------------------------
# Reader
# ---------------------------------------------------------------------------

class CSVHandler:
    """Read, parse and write sensor CSV files."""

    DEFAULT_CHUNK_SIZE = 500   # rows per chunk

    def __init__(
        self,
        data_dir: str | Path = "data",
        output_dir: str | Path = "data/processed",
        error_dir: str | Path  = "data/errors",
        chunk_size: int = DEFAULT_CHUNK_SIZE,
    ) -> None:
        self.data_dir   = Path(data_dir)
        self.output_dir = Path(output_dir)
        self.error_dir  = Path(error_dir)
        self.chunk_size = chunk_size

        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.error_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def read_file(
        self, filepath: str | Path, *, chunk_size: int | None = None
    ) -> Generator[list[dict], None, None]:
        """
        Yield chunks of normalised row dicts from *filepath*.

        Each dict has canonical field names.  Rows with critical parse
        failures are skipped (logged at WARNING).
        """
        filepath = Path(filepath)
        if not filepath.exists():
            raise FileNotFoundError(f"CSV not found: {filepath}")

        chunk: list[dict] = []
        cs = chunk_size or self.chunk_size

        logger.info("Reading CSV: %s", filepath)
        with open(filepath, newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            if reader.fieldnames is None:
                logger.warning("Empty CSV: %s", filepath)
                return

            normalised_headers = [_normalise_header(h) for h in reader.fieldnames]

            for raw_row in reader:
                row = {
                    normalised_headers[i]: v.strip() if isinstance(v, str) else v
                    for i, (_, v) in enumerate(raw_row.items())
                }
                row = self._coerce_row(row)
                chunk.append(row)

                if len(chunk) >= cs:
                    yield chunk
                    chunk = []

        if chunk:
            yield chunk

    def read_all(
        self, pattern: str = "*.csv"
    ) -> Generator[list[dict], None, None]:
        """
        Yield chunks from every CSV in *data_dir* matching *pattern*.
        Files are processed in sorted order for determinism.
        """
        files = sorted(self.data_dir.glob(pattern))
        if not files:
            logger.warning("No CSV files found in %s matching '%s'", self.data_dir, pattern)
            return

        for filepath in files:
            logger.info("Processing file: %s", filepath)
            yield from self.read_file(filepath)

    def read_from_bytes(self, raw: bytes, filename: str = "upload.csv") -> list[dict]:
        """
        Parse an in-memory CSV (e.g. from a Flask file upload).
        Returns all rows as a flat list.
        """
        text = raw.decode("utf-8-sig", errors="replace")
        reader = csv.DictReader(io.StringIO(text))
        if reader.fieldnames is None:
            return []

        normalised_headers = [_normalise_header(h) for h in reader.fieldnames]
        rows: list[dict] = []

        for raw_row in reader:
            row = {
                normalised_headers[i]: v.strip() if isinstance(v, str) else v
                for i, (_, v) in enumerate(raw_row.items())
            }
            rows.append(self._coerce_row(row))

        logger.info("Parsed %d rows from in-memory CSV '%s'", len(rows), filename)
        return rows

    # ------------------------------------------------------------------
    # Writer
    # ------------------------------------------------------------------

    def write_processed(
        self,
        records: Iterable[dict],
        filename: str | None = None,
    ) -> Path:
        """
        Write successfully processed records to *output_dir*.
        Returns the path of the written file.
        """
        filename = filename or f"processed_{_ts()}.csv"
        out_path = self.output_dir / filename

        records = list(records)
        if not records:
            logger.warning("write_processed called with empty record list.")
            return out_path

        fieldnames = list(records[0].keys())
        with open(out_path, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(records)

        logger.info("Wrote %d processed records → %s", len(records), out_path)
        return out_path

    def write_errors(
        self,
        error_rows: Iterable[dict],
        filename: str | None = None,
    ) -> Path:
        """
        Write rejected rows together with their validation error messages
        to *error_dir*.
        """
        filename = filename or f"errors_{_ts()}.csv"
        err_path = self.error_dir / filename

        error_rows = list(error_rows)
        if not error_rows:
            return err_path

        fieldnames = list(error_rows[0].keys())
        for row in error_rows:
            for k in fieldnames:
                row.setdefault(k, "")

        with open(err_path, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(error_rows)

        logger.info("Wrote %d error rows → %s", len(error_rows), err_path)
        return err_path

    def archive(self, filepath: str | Path, archive_dir: str | Path = "data/archive") -> Path:
        """Move a raw input CSV to an archive directory after processing."""
        filepath    = Path(filepath)
        archive_dir = Path(archive_dir)
        archive_dir.mkdir(parents=True, exist_ok=True)

        dest = archive_dir / f"{filepath.stem}_{_ts()}{filepath.suffix}"
        filepath.rename(dest)
        logger.info("Archived %s → %s", filepath, dest)
        return dest

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _coerce_row(row: dict) -> dict:
        """
        Best-effort type coercion: convert numeric strings to float/int,
        leave everything else as a string.
        """
        coerced: dict = {}
        for k, v in row.items():
            if v == "" or v is None:
                coerced[k] = None
                continue
            try:
                as_float = float(v)
                # Preserve integers where sensible (avoids "1.0" for IDs)
                coerced[k] = int(as_float) if as_float == int(as_float) and "." not in str(v) else as_float
            except (ValueError, TypeError):
                coerced[k] = v
        return coerced

    @staticmethod
    def generate_sample_csv(
        output_path: str | Path = "data/sensor_data.csv",
        n_rows: int = 50,
    ) -> Path:
        """
        Generate a sample sensor_data.csv with realistic-looking records.
        Useful for testing the pipeline without live hardware.
        """
        import random

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        sensor_types = ["air_quality", "water_quality", "temperature", "humidity"]
        zones = ["Zone_A", "Zone_B", "Zone_C", "Industrial_Area", "River_Basin"]

        with open(output_path, "w", newline="", encoding="utf-8") as fh:
            fieldnames = [
                "sensor_id", "sensor_type", "zone",
                "latitude", "longitude", "recorded_at",
                "pm25", "pm10", "no2", "so2", "co", "aqi",
                "bod", "cod", "ph", "toc",
                "temperature", "humidity", "status",
            ]
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            writer.writeheader()

            for i in range(n_rows):
                s_type = random.choice(sensor_types)
                row: dict = {
                    "sensor_id":   f"SENSOR_{i % 10 + 1:03d}",
                    "sensor_type": s_type,
                    "zone":        random.choice(zones),
                    "latitude":    round(random.uniform(21.0, 21.2), 6),
                    "longitude":   round(random.uniform(79.0, 79.2), 6),
                    "recorded_at": datetime.utcnow().isoformat(),
                    "status":      "active",
                }
                if s_type == "air_quality":
                    row.update({
                        "pm25": round(random.uniform(10, 150), 2),
                        "pm10": round(random.uniform(20, 200), 2),
                        "no2":  round(random.uniform(10, 180), 2),
                        "so2":  round(random.uniform(5,  120), 2),
                        "co":   round(random.uniform(0.1, 8),  2),
                        "aqi":  round(random.uniform(30, 350), 1),
                    })
                elif s_type == "water_quality":
                    row.update({
                        "bod": round(random.uniform(5, 80),   2),
                        "cod": round(random.uniform(20, 400), 2),
                        "ph":  round(random.uniform(5.5, 9),  2),
                        "toc": round(random.uniform(2, 40),   2),
                    })
                elif s_type == "temperature":
                    row["temperature"] = round(random.uniform(15, 48), 1)
                elif s_type == "humidity":
                    row["humidity"] = round(random.uniform(30, 95), 1)

                writer.writerow(row)

        logger.info("Generated sample CSV with %d rows → %s", n_rows, output_path)
        return output_path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ts() -> str:
    return datetime.utcnow().strftime("%Y%m%d_%H%M%S")
