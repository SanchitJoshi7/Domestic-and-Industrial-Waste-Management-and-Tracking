"""
sensor_processor.py
====================
Orchestrates the end-to-end sensor data pipeline:

  CSV files / API payloads
        ↓
  CSVHandler  (read & normalise)
        ↓
  DataValidator (validate & clean)
        ↓
  Backend API  (POST /sensors/ingest)  ← or local SQLite fallback
        ↓
  CSVHandler  (write processed / error CSVs)
        ↓
  Logs

The processor is designed to be called directly (one-shot batch) or
invoked repeatedly by the scheduler.
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import requests

from csv_handler import CSVHandler
from data_validator import DataValidator, ValidationResult

logger = logging.getLogger("data_processor.sensor_processor")

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

BACKEND_INGEST_URL = os.environ.get(
    "BACKEND_INGEST_URL", "http://localhost:5000/sensors/ingest"
)
BACKEND_TIMEOUT    = int(os.environ.get("BACKEND_TIMEOUT", "10"))
BATCH_SIZE         = int(os.environ.get("INGEST_BATCH_SIZE", "100"))
MAX_RETRIES        = int(os.environ.get("INGEST_MAX_RETRIES", "3"))
RETRY_BACKOFF      = float(os.environ.get("INGEST_RETRY_BACKOFF", "2.0"))

# ---------------------------------------------------------------------------
# Pipeline result
# ---------------------------------------------------------------------------

@dataclass
class PipelineRun:
    started_at:  datetime = field(default_factory=datetime.utcnow)
    finished_at: datetime | None = None

    total_read:      int = 0
    total_valid:     int = 0
    total_warnings:  int = 0
    total_invalid:   int = 0
    total_ingested:  int = 0
    total_failed:    int = 0

    validation_results: list[ValidationResult] = field(default_factory=list)
    ingest_errors:      list[dict]             = field(default_factory=list)

    @property
    def duration_seconds(self) -> float | None:
        if self.finished_at:
            return (self.finished_at - self.started_at).total_seconds()
        return None

    def summary(self) -> dict:
        return {
            "started_at":     self.started_at.isoformat(),
            "finished_at":    self.finished_at.isoformat() if self.finished_at else None,
            "duration_s":     self.duration_seconds,
            "total_read":     self.total_read,
            "total_valid":    self.total_valid,
            "total_warnings": self.total_warnings,
            "total_invalid":  self.total_invalid,
            "total_ingested": self.total_ingested,
            "total_failed":   self.total_failed,
        }


# ---------------------------------------------------------------------------
# Processor
# ---------------------------------------------------------------------------

class SensorProcessor:
    """
    Full pipeline: read → validate → ingest → report.

    Parameters
    ----------
    data_dir      : directory that contains raw CSV files
    output_dir    : where processed rows are written
    error_dir     : where rejected rows are written
    log_dir       : where JSON run-summaries are written
    backend_url   : POST endpoint for the Flask backend
    dry_run       : if True, skip HTTP ingestion (useful for testing)
    """

    def __init__(
        self,
        data_dir:    str = "data",
        output_dir:  str = "data/processed",
        error_dir:   str = "data/errors",
        log_dir:     str = "logs",
        backend_url: str = BACKEND_INGEST_URL,
        dry_run:     bool = False,
    ) -> None:
        self.csv_handler = CSVHandler(
            data_dir=data_dir,
            output_dir=output_dir,
            error_dir=error_dir,
        )
        self.validator   = DataValidator()
        self.backend_url = backend_url
        self.log_dir     = Path(log_dir)
        self.dry_run     = dry_run

        self.log_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run_batch(self, csv_pattern: str = "*.csv") -> PipelineRun:
        """
        Process every CSV in data_dir that matches *csv_pattern*.
        Returns a PipelineRun with full statistics.
        """
        run = PipelineRun()
        logger.info("=== Pipeline run started ===")

        valid_rows:   list[dict] = []
        invalid_rows: list[dict] = []

        for chunk in self.csv_handler.read_all(pattern=csv_pattern):
            v_results = self.validator.validate_batch(chunk)
            run.total_read += len(chunk)

            for record, result in zip(chunk, v_results):
                run.validation_results.append(result)

                if result.is_valid:
                    run.total_valid += 1
                    if result.has_warnings:
                        run.total_warnings += 1
                    valid_rows.append(result.cleaned_record or record)
                else:
                    run.total_invalid += 1
                    error_row = dict(record)
                    error_row["_validation_errors"] = "; ".join(
                        f"{i.field}: {i.message}" for i in result.errors
                    )
                    invalid_rows.append(error_row)

        # Ingest valid rows in batches
        if valid_rows:
            ingested, failed, errors = self._ingest_records(valid_rows)
            run.total_ingested = ingested
            run.total_failed   = failed
            run.ingest_errors  = errors

        # Persist outputs
        ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        if valid_rows:
            self.csv_handler.write_processed(valid_rows, filename=f"processed_{ts}.csv")
        if invalid_rows:
            self.csv_handler.write_errors(invalid_rows, filename=f"errors_{ts}.csv")

        run.finished_at = datetime.utcnow()
        self._write_run_log(run, ts)

        logger.info(
            "=== Pipeline complete | read=%d valid=%d invalid=%d ingested=%d failed=%d (%.1fs) ===",
            run.total_read, run.total_valid, run.total_invalid,
            run.total_ingested, run.total_failed,
            run.duration_seconds or 0,
        )
        return run

    def process_records(self, records: list[dict]) -> PipelineRun:
        """
        Process an in-memory list of records (e.g. from a live API payload).
        Validates, then ingests directly without touching the filesystem.
        """
        run = PipelineRun()
        run.total_read = len(records)

        valid_rows: list[dict] = []
        for record in records:
            result = self.validator.validate(record)
            run.validation_results.append(result)
            if result.is_valid:
                run.total_valid += 1
                if result.has_warnings:
                    run.total_warnings += 1
                valid_rows.append(result.cleaned_record or record)
            else:
                run.total_invalid += 1

        if valid_rows:
            ingested, failed, errors = self._ingest_records(valid_rows)
            run.total_ingested = ingested
            run.total_failed   = failed
            run.ingest_errors  = errors

        run.finished_at = datetime.utcnow()
        return run

    def process_csv_bytes(self, raw: bytes, filename: str = "upload.csv") -> PipelineRun:
        """
        Parse an uploaded CSV from raw bytes and run the full pipeline.
        Returns a PipelineRun.
        """
        rows = self.csv_handler.read_from_bytes(raw, filename=filename)
        return self.process_records(rows)

    # ------------------------------------------------------------------
    # Ingestion helpers
    # ------------------------------------------------------------------

    def _ingest_records(
        self, records: list[dict]
    ) -> tuple[int, int, list[dict]]:
        """
        Send *records* to the backend in batches.
        Returns (ingested_count, failed_count, error_list).
        """
        if self.dry_run:
            logger.info("[DRY RUN] Would ingest %d records", len(records))
            return len(records), 0, []

        ingested = 0
        failed   = 0
        errors: list[dict] = []

        for i in range(0, len(records), BATCH_SIZE):
            batch = records[i : i + BATCH_SIZE]
            ok, err = self._post_with_retry(batch)
            if ok:
                ingested += len(batch)
            else:
                failed += len(batch)
                errors.append({"batch_start": i, "count": len(batch), "error": err})

        return ingested, failed, errors

    def _post_with_retry(
        self, batch: list[dict]
    ) -> tuple[bool, str | None]:
        """POST a batch to the backend with exponential backoff retry."""
        last_error: str = "Unknown error"

        for attempt in range(1, MAX_RETRIES + 1):
            try:
                resp = requests.post(
                    self.backend_url,
                    json=batch,
                    timeout=BACKEND_TIMEOUT,
                    headers={"Content-Type": "application/json"},
                )
                if resp.status_code in (200, 201):
                    logger.debug(
                        "Ingested batch of %d records (attempt %d)", len(batch), attempt
                    )
                    return True, None
                last_error = f"HTTP {resp.status_code}: {resp.text[:200]}"
                logger.warning("Ingest attempt %d failed: %s", attempt, last_error)
            except requests.RequestException as exc:
                last_error = str(exc)
                logger.warning("Ingest attempt %d error: %s", attempt, last_error)

            if attempt < MAX_RETRIES:
                sleep_time = RETRY_BACKOFF ** attempt
                logger.info("Retrying in %.1fs …", sleep_time)
                time.sleep(sleep_time)

        logger.error("All %d ingest attempts failed: %s", MAX_RETRIES, last_error)
        return False, last_error

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------

    def _write_run_log(self, run: PipelineRun, ts: str) -> None:
        log_path = self.log_dir / f"run_{ts}.json"
        try:
            with open(log_path, "w", encoding="utf-8") as fh:
                json.dump(run.summary(), fh, indent=2)
            logger.info("Run log written → %s", log_path)
        except OSError as exc:
            logger.error("Failed to write run log: %s", exc)


# ---------------------------------------------------------------------------
# CLI entry-point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    parser = argparse.ArgumentParser(description="EcoWatch Sensor Data Processor")
    parser.add_argument("--data-dir",    default="data",           help="Directory with input CSVs")
    parser.add_argument("--output-dir",  default="data/processed", help="Directory for processed output")
    parser.add_argument("--error-dir",   default="data/errors",    help="Directory for error rows")
    parser.add_argument("--log-dir",     default="logs",           help="Directory for run logs")
    parser.add_argument("--backend-url", default=BACKEND_INGEST_URL)
    parser.add_argument("--pattern",     default="*.csv",          help="Glob pattern for CSV files")
    parser.add_argument("--dry-run",     action="store_true",      help="Skip HTTP ingestion")
    parser.add_argument("--generate-sample", action="store_true",  help="Generate sample CSV and exit")
    args = parser.parse_args()

    if args.generate_sample:
        CSVHandler.generate_sample_csv(Path(args.data_dir) / "sensor_data.csv")
    else:
        processor = SensorProcessor(
            data_dir=args.data_dir,
            output_dir=args.output_dir,
            error_dir=args.error_dir,
            log_dir=args.log_dir,
            backend_url=args.backend_url,
            dry_run=args.dry_run,
        )
        result = processor.run_batch(csv_pattern=args.pattern)
        print(json.dumps(result.summary(), indent=2))
