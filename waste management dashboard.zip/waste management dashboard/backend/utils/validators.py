import re
from typing import Tuple, Optional

def validate_email(email: str) -> Tuple[bool, Optional[str]]:
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not email or not isinstance(email, str):
        return False, "Email must be a non-empty string"
    if not re.match(pattern, email):
        return False, "Invalid email format"
    if len(email) > 255:
        return False, "Email too long (max 255 characters)"
    return True, None

def validate_phone(phone: str) -> Tuple[bool, Optional[str]]:
    if not phone or not isinstance(phone, str):
        return False, "Phone must be a non-empty string"
    
    phone = phone.strip()
    cleaned = re.sub(r'[\s\-]', '', phone)
    
    patterns = [
        r'^\+91\d{10}$',
        r'^91\d{10}$',
        r'^\d{10}$',
    ]
    
    for pattern in patterns:
        if re.match(pattern, cleaned):
            return True, None
    
    return False, "Invalid phone number format"

def validate_coordinates(lat: float, lng: float) -> Tuple[bool, Optional[str]]:
    try:
        lat_float = float(lat)
        lng_float = float(lng)
    except (TypeError, ValueError):
        return False, "Coordinates must be numeric"
    
    if not (-90 <= lat_float <= 90):
        return False, "Latitude must be between -90 and 90"
    if not (-180 <= lng_float <= 180):
        return False, "Longitude must be between -180 and 180"
    
    return True, None

def validate_alert_submission(data: dict) -> Tuple[bool, Optional[str]]:
    required_fields = ['title', 'description', 'user_name', 'user_email', 'location']
    
    for field in required_fields:
        if field not in data or not data[field]:
            return False, f"Missing required field: {field}"
    
    if len(data.get('title', '')) < 3:
        return False, "Title must be at least 3 characters"
    
    if len(data.get('description', '')) < 10:
        return False, "Description must be at least 10 characters"
    
    email_valid, email_error = validate_email(data.get('user_email', ''))
    if not email_valid:
        return False, email_error
    
    if data.get('user_phone'):
        phone_valid, phone_error = validate_phone(data.get('user_phone', ''))
        if not phone_valid:
            return False, phone_error
    
    return True, None

def validate_csv_file(filename: str) -> Tuple[bool, Optional[str]]:
    if not filename:
        return False, "No filename provided"
    
    if not filename.lower().endswith('.csv'):
        return False, "Only CSV files are allowed"
    
    return True, None
