ALERT_CATEGORIES = {
    'air': 'Air Quality',
    'water': 'Water Pollution',
    'waste': 'Waste Management',
    'noise': 'Noise Pollution',
    'industrial': 'Industrial Emissions',
    'domestic': 'Domestic Waste',
    'general': 'General Environmental Issue'
}

SEVERITY_LEVELS = {
    'low': {'value': 1, 'color': '#4CAF50', 'label': 'Low'},
    'medium': {'value': 2, 'color': '#FFC107', 'label': 'Medium'},
    'high': {'value': 3, 'color': '#FF9800', 'label': 'High'},
    'critical': {'value': 4, 'color': '#F44336', 'label': 'Critical'}
}

ALERT_STATUS = {
    'submitted': 'Alert Submitted',
    'acknowledged': 'Acknowledged by Authority',
    'processing': 'Under Processing',
    'resolved': 'Resolved',
    'rejected': 'Rejected',
    'closed': 'Closed'
}

WASTE_TYPES = {
    'solid': {
        'name': 'Solid Waste',
        'unit': 'Metric Tons/Month',
        'subcategories': ['Construction', 'Municipal', 'Hazardous', 'E-Waste']
    },
    'liquid': {
        'name': 'Liquid Waste',
        'unit': 'Cubic Meters/Month',
        'subcategories': ['Industrial', 'Domestic', 'Sewage', 'Hazardous']
    },
    'air': {
        'name': 'Air Emissions',
        'unit': 'Metric Tons CO₂ Eq./Month',
        'subcategories': ['Industrial', 'Vehicular', 'Residential', 'Commercial']
    }
}

POLLUTANTS = {
    'pm25': {
        'name': 'PM2.5',
        'description': 'Fine Particulate Matter',
        'unit': 'µg/m³',
        'thresholds': {
            'good': {'min': 0, 'max': 30, 'color': '#4CAF50'},
            'satisfactory': {'min': 30, 'max': 60, 'color': '#8BC34A'},
            'moderately_polluted': {'min': 60, 'max': 90, 'color': '#FBC02D'},
            'poor': {'min': 90, 'max': 120, 'color': '#FF9800'},
            'very_poor': {'min': 120, 'max': 250, 'color': '#F44336'},
            'severe': {'min': 250, 'max': float('inf'), 'color': '#6A1B9A'}
        }
    },
    'pm10': {
        'name': 'PM10',
        'description': 'Particulate Matter',
        'unit': 'µg/m³',
        'thresholds': {
            'good': {'min': 0, 'max': 50, 'color': '#4CAF50'},
            'satisfactory': {'min': 50, 'max': 100, 'color': '#8BC34A'},
            'moderately_polluted': {'min': 100, 'max': 150, 'color': '#FBC02D'},
            'poor': {'min': 150, 'max': 200, 'color': '#FF9800'},
            'very_poor': {'min': 200, 'max': 400, 'color': '#F44336'},
            'severe': {'min': 400, 'max': float('inf'), 'color': '#6A1B9A'}
        }
    },
    'no2': {
        'name': 'NO₂',
        'description': 'Nitrogen Dioxide',
        'unit': 'ppb',
        'thresholds': {
            'good': {'min': 0, 'max': 40, 'color': '#4CAF50'},
            'satisfactory': {'min': 40, 'max': 80, 'color': '#8BC34A'},
            'moderately_polluted': {'min': 80, 'max': 150, 'color': '#FBC02D'},
            'poor': {'min': 150, 'max': 250, 'color': '#FF9800'},
            'very_poor': {'min': 250, 'max': 500, 'color': '#F44336'},
            'severe': {'min': 500, 'max': float('inf'), 'color': '#6A1B9A'}
        }
    },
    'so2': {
        'name': 'SO₂',
        'description': 'Sulfur Dioxide',
        'unit': 'ppb',
        'thresholds': {
            'good': {'min': 0, 'max': 40, 'color': '#4CAF50'},
            'satisfactory': {'min': 40, 'max': 100, 'color': '#8BC34A'},
            'moderately_polluted': {'min': 100, 'max': 200, 'color': '#FBC02D'},
            'poor': {'min': 200, 'max': 350, 'color': '#FF9800'},
            'very_poor': {'min': 350, 'max': 500, 'color': '#F44336'},
            'severe': {'min': 500, 'max': float('inf'), 'color': '#6A1B9A'}
        }
    },
    'aqi': {
        'name': 'AQI',
        'description': 'Air Quality Index',
        'unit': 'Index',
        'thresholds': {
            'good': {'min': 0, 'max': 50, 'color': '#4CAF50'},
            'satisfactory': {'min': 50, 'max': 100, 'color': '#8BC34A'},
            'moderately_polluted': {'min': 100, 'max': 200, 'color': '#FBC02D'},
            'poor': {'min': 200, 'max': 300, 'color': '#FF9800'},
            'very_poor': {'min': 300, 'max': 400, 'color': '#F44336'},
            'severe': {'min': 400, 'max': float('inf'), 'color': '#6A1B9A'}
        }
    }
}

AUTHORITIES = [
    {
        'id': 'municipality',
        'name': 'Municipality',
        'icon': '🏛️',
        'email': 'alerts@municipality.gov.in',
        'description': 'Local municipal corporation',
        'contact': '+91-XXXX-XXXXXX'
    },
    {
        'id': 'spcb',
        'name': 'State Pollution Control Board',
        'icon': '🌍',
        'email': 'grievances@spcb.gov.in',
        'description': 'State authority for pollution',
        'contact': '+91-XXXX-XXXXXX'
    },
    {
        'id': 'cpcb',
        'name': 'Central Pollution Control Board',
        'icon': '🏢',
        'email': 'complaints@cpcb.gov.in',
        'description': 'National environmental authority',
        'contact': '+91-XXXX-XXXXXX'
    }
]

HTTP_STATUS = {
    'ok': 200,
    'created': 201,
    'bad_request': 400,
    'unauthorized': 401,
    'forbidden': 403,
    'not_found': 404,
    'conflict': 409,
    'server_error': 500
}

PAGINATION = {
    'default_page': 1,
    'default_per_page': 10,
    'max_per_page': 100
}
