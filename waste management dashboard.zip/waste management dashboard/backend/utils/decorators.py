from functools import wraps
from flask import request, jsonify
from typing import Callable, Any

def require_auth(f: Callable) -> Callable:
    @wraps(f)
    def decorated_function(*args, **kwargs) -> Any:
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({'error': 'Missing authorization token'}), 401
        
        try:
            parts = token.split()
            if len(parts) != 2 or parts[0] != 'Bearer':
                return jsonify({'error': 'Invalid token format'}), 401
            
        except Exception as e:
            return jsonify({'error': f'Token validation failed: {str(e)}'}), 401
        
        return f(*args, **kwargs)
    
    return decorated_function

def require_role(required_roles):
    if isinstance(required_roles, str):
        required_roles = [required_roles]
    
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs) -> Any:
            user_role = request.headers.get('X-User-Role')
            
            if not user_role:
                return jsonify({'error': 'User role not found'}), 403
            
            if user_role not in required_roles:
                return jsonify({
                    'error': f'Insufficient permissions. Required roles: {required_roles}'
                }), 403
            
            return f(*args, **kwargs)
        
        return decorated_function
    
    return decorator

def handle_errors(f: Callable) -> Callable:
    @wraps(f)
    def decorated_function(*args, **kwargs) -> Any:
        try:
            return f(*args, **kwargs)
        except ValueError as ve:
            return jsonify({'error': f'Invalid input: {str(ve)}'}), 400
        except Exception as e:
            return jsonify({'error': f'Internal server error: {str(e)}'}), 500
    
    return decorated_function
