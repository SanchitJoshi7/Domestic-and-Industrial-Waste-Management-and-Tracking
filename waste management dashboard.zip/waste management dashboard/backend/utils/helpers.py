from typing import Dict, List, Any, Tuple, Optional
from datetime import datetime
import re
import os

def paginate(items: List[Any], page: int = 1, per_page: int = 10) -> Dict[str, Any]:
    total = len(items)
    pages = (total + per_page - 1) // per_page
    
    if page < 1 or page > pages:
        page = 1
    
    start = (page - 1) * per_page
    end = start + per_page
    
    return {
        'items': items[start:end],
        'total': total,
        'page': page,
        'per_page': per_page,
        'pages': pages
    }

def format_response(success: bool, data: Any = None, message: str = '', status_code: int = 200) -> Tuple[Dict, int]:
    response = {
        'success': success,
        'timestamp': datetime.now().isoformat(),
    }
    
    if data is not None:
        response['data'] = data
    
    if message:
        response['message'] = message
    
    return response, status_code

def calculate_severity(pollutant_level: float, pollutant_type: str = 'generic') -> str:
    severity_thresholds = {
        'pm25': {'low': 50, 'medium': 100, 'high': 250},
        'pm10': {'low': 100, 'medium': 200, 'high': 500},
        'no2': {'low': 80, 'medium': 150, 'high': 400},
        'so2': {'low': 100, 'medium': 200, 'high': 500},
        'aqi': {'low': 100, 'medium': 200, 'high': 300},
        'generic': {'low': 50, 'medium': 100, 'high': 200}
    }
    
    thresholds = severity_thresholds.get(pollutant_type.lower(), severity_thresholds['generic'])
    
    if pollutant_level < thresholds['low']:
        return 'low'
    elif pollutant_level < thresholds['medium']:
        return 'medium'
    elif pollutant_level < thresholds['high']:
        return 'high'
    else:
        return 'critical'

def format_datetime(dt: datetime, format_str: str = '%Y-%m-%d %H:%M:%S') -> str:
    if isinstance(dt, str):
        return dt
    return dt.strftime(format_str) if dt else None

def parse_datetime(date_str: str, format_str: str = '%Y-%m-%d %H:%M:%S') -> Optional[datetime]:
    try:
        return datetime.strptime(date_str, format_str)
    except (ValueError, TypeError):
        return None

def sanitize_filename(filename: str) -> str:
    filename = os.path.basename(filename)
    filename = re.sub(r'[^\w\s.-]', '', filename)
    return filename

def format_number(value: float, decimals: int = 2) -> float:
    try:
        return round(float(value), decimals)
    except (ValueError, TypeError):
        return 0.0

def filter_dict(data: Dict, allowed_keys: List[str]) -> Dict:
    return {k: v for k, v in data.items() if k in allowed_keys}

def merge_dicts(*dicts) -> Dict:
    result = {}
    for d in dicts:
        if isinstance(d, dict):
            result.update(d)
    return result
