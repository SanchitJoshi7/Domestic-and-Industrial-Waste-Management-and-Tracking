from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# Import all models after db is created to avoid circular imports
def init_models():
    from .user import User
    from .alert import Alert
    from .sensor_data import SensorData
    from .authority import Authority
    from .audit_log import AuditLog
    
    return {
        'User': User,
        'Alert': Alert,
        'SensorData': SensorData,
        'Authority': Authority,
        'AuditLog': AuditLog
    }

# Import models for convenience
from .user import User
from .alert import Alert
from .sensor_data import SensorData
from .authority import Authority
from .audit_log import AuditLog

__all__ = ['db', 'User', 'Alert', 'SensorData', 'Authority', 'AuditLog', 'init_models']
