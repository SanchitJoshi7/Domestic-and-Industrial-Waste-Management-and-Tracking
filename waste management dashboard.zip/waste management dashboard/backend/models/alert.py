from datetime import datetime
from models import db


class Alert(db.Model):
    """Citizen-submitted environmental alert forwarded to an authority."""

    __tablename__ = "alerts"

    id = db.Column(db.Integer, primary_key=True)

    # Submitter (FK nullable so alerts survive user deletion)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    user = db.relationship("User", back_populates="alerts")

    # Contact snapshot at submission time (in case user changes details later)
    submitter_name = db.Column(db.String(120), nullable=False)
    submitter_email = db.Column(db.String(255), nullable=False)
    submitter_phone = db.Column(db.String(20), nullable=True)

    # Alert payload
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(60), default="general", nullable=False)
    # categories: air | water | waste | noise | industrial | general

    severity = db.Column(db.String(20), default="medium", nullable=False)
    # severities: low | medium | high | critical

    # Location
    location = db.Column(db.String(255), nullable=True)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)

    # Target authority
    authority_id = db.Column(db.Integer, db.ForeignKey("authorities.id", ondelete="SET NULL"), nullable=True)
    authority = db.relationship("Authority", back_populates="alerts")
    authority_name = db.Column(db.String(120), nullable=True)  # snapshot

    # Lifecycle
    status = db.Column(db.String(30), default="submitted", nullable=False, index=True)
    # statuses: submitted | acknowledged | in_progress | resolved | rejected

    resolution_notes = db.Column(db.Text, nullable=True)
    resolved_at = db.Column(db.DateTime, nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "submitter_name": self.submitter_name,
            "submitter_email": self.submitter_email,
            "submitter_phone": self.submitter_phone,
            "title": self.title,
            "description": self.description,
            "category": self.category,
            "severity": self.severity,
            "location": self.location,
            "latitude": self.latitude,
            "longitude": self.longitude,
            "authority_id": self.authority_id,
            "authority_name": self.authority_name,
            "status": self.status,
            "resolution_notes": self.resolution_notes,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self) -> str:
        return f"<Alert #{self.id} [{self.severity}] {self.title[:40]}>"
