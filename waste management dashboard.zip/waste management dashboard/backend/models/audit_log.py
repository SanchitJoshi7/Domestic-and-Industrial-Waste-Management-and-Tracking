from datetime import datetime
from models import db


class AuditLog(db.Model):
    """Immutable record of security-relevant actions performed in the system."""

    __tablename__ = "audit_logs"

    id = db.Column(db.Integer, primary_key=True)

    # Actor (nullable – system-generated events have no user)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    user = db.relationship("User", back_populates="audit_logs")
    ip_address = db.Column(db.String(45), nullable=True)   # supports IPv6
    user_agent = db.Column(db.String(512), nullable=True)

    # Action descriptor
    action = db.Column(db.String(80), nullable=False, index=True)
    # e.g. "user.login", "user.register", "alert.submit", "user.update_role"

    resource_type = db.Column(db.String(60), nullable=True)
    # e.g. "user", "alert", "sensor"
    resource_id = db.Column(db.String(60), nullable=True)

    # Free-form payload (JSON) for before/after state or extra context
    details = db.Column(db.JSON, nullable=True)

    status = db.Column(db.String(20), default="success", nullable=False)
    # statuses: success | failure | error

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    # ------------------------------------------------------------------
    # Class-level factory
    # ------------------------------------------------------------------
    @classmethod
    def log(
        cls,
        action: str,
        user_id: int | None = None,
        ip_address: str | None = None,
        user_agent: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        details: dict | None = None,
        status: str = "success",
    ) -> "AuditLog":
        entry = cls(
            action=action,
            user_id=user_id,
            ip_address=ip_address,
            user_agent=user_agent,
            resource_type=resource_type,
            resource_id=str(resource_id) if resource_id is not None else None,
            details=details,
            status=status,
        )
        db.session.add(entry)
        return entry

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "ip_address": self.ip_address,
            "action": self.action,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "details": self.details,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

    def __repr__(self) -> str:
        return f"<AuditLog {self.action} user={self.user_id} @ {self.created_at}>"
