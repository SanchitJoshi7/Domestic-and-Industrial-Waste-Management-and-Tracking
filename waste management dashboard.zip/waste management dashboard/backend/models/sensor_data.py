from datetime import datetime
from models import db


class SensorData(db.Model):
    """Time-series reading from an IoT / field sensor."""

    __tablename__ = "sensor_data"

    id = db.Column(db.Integer, primary_key=True)
    sensor_id = db.Column(db.String(64), nullable=False, index=True)
    sensor_type = db.Column(db.String(50), nullable=False)
    # sensor_types: air_quality | water_quality | noise | temperature | humidity

    zone = db.Column(db.String(100), nullable=True, index=True)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)

    # Core pollutant / environmental readings (nullable – not every sensor
    # measures every parameter)
    pm25 = db.Column(db.Float, nullable=True)      # µg/m³
    pm10 = db.Column(db.Float, nullable=True)      # µg/m³
    no2 = db.Column(db.Float, nullable=True)       # ppb
    so2 = db.Column(db.Float, nullable=True)       # ppb
    co = db.Column(db.Float, nullable=True)        # ppm
    aqi = db.Column(db.Float, nullable=True)

    bod = db.Column(db.Float, nullable=True)       # mg/L – water
    cod = db.Column(db.Float, nullable=True)       # mg/L – water
    ph = db.Column(db.Float, nullable=True)
    toc = db.Column(db.Float, nullable=True)       # mg/L

    temperature = db.Column(db.Float, nullable=True)   # °C
    humidity = db.Column(db.Float, nullable=True)      # %

    # Status flag set by ingestion pipeline
    status = db.Column(db.String(20), default="active", nullable=False)
    # statuses: active | maintenance | offline | error

    recorded_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "sensor_id": self.sensor_id,
            "sensor_type": self.sensor_type,
            "zone": self.zone,
            "latitude": self.latitude,
            "longitude": self.longitude,
            "readings": {
                "pm25": self.pm25,
                "pm10": self.pm10,
                "no2": self.no2,
                "so2": self.so2,
                "co": self.co,
                "aqi": self.aqi,
                "bod": self.bod,
                "cod": self.cod,
                "ph": self.ph,
                "toc": self.toc,
                "temperature": self.temperature,
                "humidity": self.humidity,
            },
            "status": self.status,
            "recorded_at": self.recorded_at.isoformat() if self.recorded_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

    def __repr__(self) -> str:
        return f"<SensorData sensor={self.sensor_id} @ {self.recorded_at}>"
