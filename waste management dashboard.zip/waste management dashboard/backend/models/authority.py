from datetime import datetime
from models import db


class Authority(db.Model):
    """Government / regulatory authority that receives alerts."""

    __tablename__ = "authorities"

    id = db.Column(db.Integer, primary_key=True)
    slug = db.Column(db.String(60), unique=True, nullable=False, index=True)
    # e.g. "municipality", "spcb", "cpcb"

    name = db.Column(db.String(120), nullable=False)
    icon = db.Column(db.String(10), nullable=True)       # emoji shorthand
    email = db.Column(db.String(255), nullable=True)
    phone = db.Column(db.String(30), nullable=True)
    description = db.Column(db.Text, nullable=True)

    # JSON-serialised list of template strings
    templates = db.Column(db.JSON, default=list, nullable=False)

    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    alerts = db.relationship("Alert", back_populates="authority", lazy="dynamic")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "slug": self.slug,
            "name": self.name,
            "icon": self.icon,
            "email": self.email,
            "phone": self.phone,
            "description": self.description,
            "templates": self.templates or [],
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

    def __repr__(self) -> str:
        return f"<Authority {self.slug}>"
