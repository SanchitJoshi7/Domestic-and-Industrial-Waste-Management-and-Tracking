import os
from datetime import datetime

import pandas as pd
from flask import Blueprint, jsonify, request

alerts_bp = Blueprint("alerts", __name__)

# ---------------------------------------------------------------------------
# In-memory store (persisted to CSV)
# ---------------------------------------------------------------------------
alerts_log = []
_ALERTS_CSV = "alerts.csv"


def _save():
    if alerts_log:
        pd.DataFrame(alerts_log).to_csv(_ALERTS_CSV, index=False)


def _load_from_csv():
    global alerts_log
    if os.path.exists(_ALERTS_CSV):
        try:
            alerts_log = pd.read_csv(_ALERTS_CSV).to_dict("records")
        except Exception:
            alerts_log = []


# Load saved alerts when the module is imported
_load_from_csv()

_AUTHORITIES = [
    {
        "id": "municipality",
        "name": "Municipality",
        "icon": "🏛️",
        "email": "alerts@municipality.gov.in",
        "description": "Local municipal corporation for waste management",
        "contact": "+91-XXXX-XXXXXX",
        "templates": [
            "Illegal dumping site found in residential area",
            "Waste collection vehicle not arrived for pickup",
            "Foul smell from local waste dump",
            "Water contamination near dump site",
            "Waste saturation in locality",
        ],
    },
    {
        "id": "spcb",
        "name": "State Pollution Control Board",
        "icon": "🌍",
        "email": "grievances@spcb.gov.in",
        "description": "State authority for pollution monitoring and regulation",
        "contact": "+91-XXXX-XXXXXX",
        "templates": [
            "High pollution levels detected",
            "Industrial effluent discharge observed",
            "Air quality below standards",
            "Water quality degradation",
            "Hazardous waste disposal",
        ],
    },
    {
        "id": "cpcb",
        "name": "Central Pollution Control Board",
        "icon": "🏢",
        "email": "complaints@cpcb.gov.in",
        "description": "National environmental protection authority",
        "contact": "+91-XXXX-XXXXXX",
        "templates": [
            "Cross-state pollution incident",
            "Major industrial contamination",
            "National environmental emergency",
            "Compliance violation by large industry",
            "National water pollution crisis",
        ],
    },
]


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@alerts_bp.route("/authorities", methods=["GET"])
def get_authorities():
    return jsonify(_AUTHORITIES)


@alerts_bp.route("/submit", methods=["POST"])
def submit_alert():
    data = request.get_json() or {}

    required = ["authority_id", "title", "description", "location", "user_name", "user_email", "user_phone"]
    missing = [f for f in required if not data.get(f)]
    if missing:
        return jsonify({"error": f"Missing required fields: {', '.join(missing)}"}), 400

    alert = {
        "id":             len(alerts_log) + 1,
        "timestamp":      datetime.now().isoformat(),
        "authority_id":   data["authority_id"],
        "authority_name": data.get("authority_name", ""),
        "title":          data["title"],
        "description":    data["description"],
        "location":       data["location"],
        "latitude":       data.get("latitude", 0),
        "longitude":      data.get("longitude", 0),
        "severity":       data.get("severity", "medium"),
        "category":       data.get("category", "general"),
        "user_name":      data["user_name"],
        "user_email":     data["user_email"],
        "user_phone":     data["user_phone"],
        "attachments":    data.get("attachments", []),
        "status":         "submitted",
    }
    alerts_log.append(alert)
    _save()
    return jsonify({"message": "Alert submitted successfully",
                    "alert_id": alert["id"], "timestamp": alert["timestamp"]}), 201


@alerts_bp.route("/history", methods=["GET"])
def get_alert_history():
    limit           = request.args.get("limit", 100, type=int)
    authority_filter = request.args.get("authority")
    filtered        = [a for a in alerts_log if not authority_filter or a["authority_id"] == authority_filter]
    sorted_alerts   = sorted(filtered, key=lambda x: x["timestamp"], reverse=True)[:limit]
    return jsonify({"total": len(alerts_log), "returned": len(sorted_alerts), "alerts": sorted_alerts})


@alerts_bp.route("/<int:alert_id>", methods=["GET"])
def get_alert_details(alert_id):
    alert = next((a for a in alerts_log if a["id"] == alert_id), None)
    if not alert:
        return jsonify({"error": "Alert not found"}), 404
    return jsonify(alert)


@alerts_bp.route("/<int:alert_id>/status", methods=["GET", "PUT"])
def alert_status(alert_id):
    alert = next((a for a in alerts_log if a["id"] == alert_id), None)
    if not alert:
        return jsonify({"error": "Alert not found"}), 404
    if request.method == "GET":
        return jsonify({"alert_id": alert_id, "status": alert["status"]})
    data = request.get_json() or {}
    if "status" not in data:
        return jsonify({"error": "Status field required"}), 400
    alert["status"] = data["status"]
    _save()
    return jsonify({"message": "Status updated", "status": alert["status"]})


@alerts_bp.route("/statistics", methods=["GET"])
def get_alert_statistics():
    stats = {"total_alerts": len(alerts_log), "by_authority": {}, "by_status": {}, "by_severity": {}, "by_category": {}}
    for a in alerts_log:
        for key, field in [("by_authority", "authority_id"), ("by_status", "status"),
                           ("by_severity", "severity"), ("by_category", "category")]:
            val = a.get(field, "unknown")
            stats[key][val] = stats[key].get(val, 0) + 1
    return jsonify(stats)


@alerts_bp.route("/export", methods=["GET"])
def export_alerts():
    return jsonify({"export_timestamp": datetime.now().isoformat(),
                    "total_alerts": len(alerts_log), "alerts": alerts_log})


@alerts_bp.route("/health", methods=["GET"])
def health_check():
    return jsonify({"status": "ok", "service": "alerts", "stored_alerts": len(alerts_log)})
