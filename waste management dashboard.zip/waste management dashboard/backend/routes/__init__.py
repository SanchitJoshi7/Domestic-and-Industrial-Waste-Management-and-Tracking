# Routes package – import all blueprints here for convenience
from routes.auth import auth_bp
from routes.sensors import sensors_bp
from routes.users import users_bp
from routes.alerts import alerts_bp
from routes.pollution import pollution_bp
from routes.industrial import industrial_bp
from routes.domestic import domestic_bp

__all__ = [
    "auth_bp",
    "sensors_bp",
    "users_bp",
    "alerts_bp",
    "pollution_bp",
    "industrial_bp",
    "domestic_bp",
]
