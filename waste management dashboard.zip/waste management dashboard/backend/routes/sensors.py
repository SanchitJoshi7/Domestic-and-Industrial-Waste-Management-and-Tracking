from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy import func

from models import db
from models.sensor_data import SensorData
from models.user import User

sensors_bp = Blueprint("sensors", __name__)

VALID_SENSOR_TYPES = {"air_quality", "water_quality", "noise", "temperature", "humidity"}
VALID_STATUSES = {"active", "maintenance", "offline", "error"}


def _require_admin():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.role not in ("admin", "authority"):
        return jsonify({"error": "Insufficient permissions"}), 403
    return None


# ---------------------------------------------------------------------------
# GET /sensors/
# ---------------------------------------------------------------------------
@sensors_bp.route("/", methods=["GET"])
def list_sensors():
    """Return the latest reading per unique sensor_id."""
    sensor_type = request.args.get("type")
    zone = request.args.get("zone")
    status = request.args.get("status")

    # Subquery: latest record id per sensor
    latest_ids = (
        db.session.query(func.max(SensorData.id))
        .group_by(SensorData.sensor_id)
        .subquery()
    )
    q = SensorData.query.filter(SensorData.id.in_(latest_ids))

    if sensor_type:
        q = q.filter(SensorData.sensor_type == sensor_type)
    if zone:
        q = q.filter(SensorData.zone.ilike(f"%{zone}%"))
    if status:
        q = q.filter(SensorData.status == status)

    sensors = q.order_by(SensorData.sensor_id).all()
    return jsonify({
        "count": len(sensors),
        "sensors": [s.to_dict() for s in sensors],
    })


# ---------------------------------------------------------------------------
# GET /sensors/<sensor_id>
# ---------------------------------------------------------------------------
@sensors_bp.route("/<sensor_id>", methods=["GET"])
def get_sensor(sensor_id: str):
    """Return the latest reading for a specific sensor."""
    record = (
        SensorData.query
        .filter_by(sensor_id=sensor_id)
        .order_by(SensorData.recorded_at.desc())
        .first_or_404(description=f"Sensor '{sensor_id}' not found")
    )
    return jsonify(record.to_dict())


# ---------------------------------------------------------------------------
# GET /sensors/<sensor_id>/history
# ---------------------------------------------------------------------------
@sensors_bp.route("/<sensor_id>/history", methods=["GET"])
def sensor_history(sensor_id: str):
    """Return time-series history for a sensor."""
    days = request.args.get("days", 7, type=int)
    limit = min(request.args.get("limit", 500, type=int), 1000)

    since = datetime.utcnow() - timedelta(days=days)
    records = (
        SensorData.query
        .filter(
            SensorData.sensor_id == sensor_id,
            SensorData.recorded_at >= since,
        )
        .order_by(SensorData.recorded_at.asc())
        .limit(limit)
        .all()
    )

    return jsonify({
        "sensor_id": sensor_id,
        "days": days,
        "count": len(records),
        "history": [r.to_dict() for r in records],
    })


# ---------------------------------------------------------------------------
# POST /sensors/ingest
# ---------------------------------------------------------------------------
@sensors_bp.route("/ingest", methods=["POST"])
def ingest():
    """Ingest one or many sensor readings (JSON body or list)."""
    payload = request.get_json(silent=True)
    if payload is None:
        return jsonify({"error": "JSON body required"}), 400

    records = payload if isinstance(payload, list) else [payload]
    saved = []
    errors = []

    for idx, item in enumerate(records):
        sensor_id = item.get("sensor_id")
        sensor_type = item.get("sensor_type", "air_quality")

        if not sensor_id:
            errors.append({"index": idx, "error": "sensor_id is required"})
            continue
        if sensor_type not in VALID_SENSOR_TYPES:
            errors.append({"index": idx, "error": f"Invalid sensor_type '{sensor_type}'"})
            continue

        recorded_at = item.get("recorded_at")
        if recorded_at:
            try:
                recorded_at = datetime.fromisoformat(recorded_at)
            except ValueError:
                recorded_at = datetime.utcnow()
        else:
            recorded_at = datetime.utcnow()

        record = SensorData(
            sensor_id=sensor_id,
            sensor_type=sensor_type,
            zone=item.get("zone"),
            latitude=item.get("latitude"),
            longitude=item.get("longitude"),
            pm25=item.get("pm25"),
            pm10=item.get("pm10"),
            no2=item.get("no2"),
            so2=item.get("so2"),
            co=item.get("co"),
            aqi=item.get("aqi"),
            bod=item.get("bod"),
            cod=item.get("cod"),
            ph=item.get("ph"),
            toc=item.get("toc"),
            temperature=item.get("temperature"),
            humidity=item.get("humidity"),
            status=item.get("status", "active"),
            recorded_at=recorded_at,
        )
        db.session.add(record)
        saved.append(sensor_id)

    db.session.commit()

    return jsonify({
        "saved": len(saved),
        "errors": errors,
        "sensor_ids": saved,
    }), 201 if saved else 400


# ---------------------------------------------------------------------------
# GET /sensors/zones
# ---------------------------------------------------------------------------
@sensors_bp.route("/zones", methods=["GET"])
def list_zones():
    """Return a distinct list of zones that have sensor data."""
    zones = (
        db.session.query(SensorData.zone)
        .filter(SensorData.zone.isnot(None))
        .distinct()
        .order_by(SensorData.zone)
        .all()
    )
    return jsonify({"zones": [z[0] for z in zones]})


# ---------------------------------------------------------------------------
# GET /sensors/summary
# ---------------------------------------------------------------------------
@sensors_bp.route("/summary", methods=["GET"])
def summary():
    """Return aggregate stats across all active sensors."""
    total = SensorData.query.count()
    by_type = (
        db.session.query(SensorData.sensor_type, func.count())
        .group_by(SensorData.sensor_type)
        .all()
    )
    by_status = (
        db.session.query(SensorData.status, func.count())
        .group_by(SensorData.status)
        .all()
    )
    return jsonify({
        "total_readings": total,
        "by_type": {t: c for t, c in by_type},
        "by_status": {s: c for s, c in by_status},
        "timestamp": datetime.utcnow().isoformat(),
    })


# ---------------------------------------------------------------------------
# DELETE /sensors/<sensor_id>   (admin only)
# ---------------------------------------------------------------------------
@sensors_bp.route("/<sensor_id>", methods=["DELETE"])
@jwt_required()
def delete_sensor(sensor_id: str):
    """Delete ALL readings for a sensor (admin / authority only)."""
    err = _require_admin()
    if err:
        return err

    deleted = SensorData.query.filter_by(sensor_id=sensor_id).delete()
    db.session.commit()

    if deleted == 0:
        return jsonify({"error": "Sensor not found"}), 404

    return jsonify({"message": f"Deleted {deleted} record(s) for sensor '{sensor_id}'"})
