from datetime import datetime

import pandas as pd
from flask import Blueprint, jsonify, request

industrial_bp = Blueprint("industrial", __name__)

# ---------------------------------------------------------------------------
# In-memory cache
# ---------------------------------------------------------------------------
_cache = {}
_FILES = {
    "solid":  "industrial_solid_waste.csv",
    "liquid": "industrial_liquid_waste.csv",
    "air":    "industrial_air_emissions.csv",
}
_UNITS = {
    "solid":  "Metric Tons/Month",
    "liquid": "Cubic Meters/Month",
    "air":    "Metric Tons CO₂ Eq./Month",
}
VALID_TYPES = set(_FILES.keys())


def _load(waste_type):
    if waste_type not in _cache:
        try:
            _cache[waste_type] = pd.read_csv(_FILES[waste_type])
        except FileNotFoundError:
            return None
    return _cache[waste_type]


def _safe_float(val):
    try:
        return float(val)
    except (TypeError, ValueError):
        return 0.0


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@industrial_bp.route("/types", methods=["GET"])
def get_waste_types():
    return jsonify({
        "types": list(VALID_TYPES),
        "descriptions": {
            "solid":  "Solid Waste Management",
            "liquid": "Liquid Waste Management",
            "air":    "Air Emissions Monitoring",
        },
    })


@industrial_bp.route("/data/<waste_type>", methods=["GET"])
def get_industrial_data(waste_type):
    if waste_type not in VALID_TYPES:
        return jsonify({"error": f"Invalid waste type. Must be one of {sorted(VALID_TYPES)}"}), 400

    df = _load(waste_type)
    if df is None:
        return jsonify({"error": f"Data for '{waste_type}' not found"}), 404

    industries = []
    for record in df.to_dict("records"):
        industries.append({k: _safe_float(v) if isinstance(v, float) else v for k, v in record.items()})

    return jsonify({"type": waste_type, "industries": industries,
                    "count": len(industries), "timestamp": datetime.now().isoformat()})


@industrial_bp.route("/summary/<waste_type>", methods=["GET"])
def get_waste_summary(waste_type):
    if waste_type not in VALID_TYPES:
        return jsonify({"error": "Invalid waste type"}), 400

    df = _load(waste_type)
    if df is None:
        return jsonify({"error": "Data not found"}), 404

    tonnage_col = "Tonnage" if "Tonnage" in df.columns else "Quantity"
    total = float(df[tonnage_col].sum()) if tonnage_col in df.columns else 0.0

    summary = {
        "waste_type":        waste_type,
        "total":             total,
        "unit":              _UNITS[waste_type],
        "industries_count":  len(df),
        "timestamp":         datetime.now().isoformat(),
    }
    if "Compliance" in df.columns:
        summary["compliance_rate"] = float(df["Compliance"].mean())

    return jsonify(summary)


@industrial_bp.route("/industry/<industry_name>", methods=["GET"])
def get_industry_details(industry_name):
    waste_type = request.args.get("type", "solid")
    df = _load(waste_type)
    if df is None:
        return jsonify({"error": "Data not found"}), 404

    industry_data = df[df["Industry"] == industry_name]
    if industry_data.empty:
        return jsonify({"error": f"Industry '{industry_name}' not found"}), 404

    record = {k: _safe_float(v) if isinstance(v, float) else v
              for k, v in industry_data.iloc[0].to_dict().items()}
    return jsonify(record)


@industrial_bp.route("/upload/<waste_type>", methods=["POST"])
def upload_industrial_csv(waste_type):
    if waste_type not in VALID_TYPES:
        return jsonify({"error": "Invalid waste type"}), 400
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    file = request.files["file"]
    if not file.filename.endswith(".csv"):
        return jsonify({"error": "Only CSV files allowed"}), 400
    try:
        _cache[waste_type] = pd.read_csv(file)
        return jsonify({"message": f"{waste_type} data uploaded",
                        "rows": len(_cache[waste_type]), "columns": list(_cache[waste_type].columns)})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@industrial_bp.route("/health", methods=["GET"])
def health_check():
    return jsonify({"status": "ok", "service": "industrial_waste"})
