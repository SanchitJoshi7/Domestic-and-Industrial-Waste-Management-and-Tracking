from datetime import datetime

from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity

from models import db
from models.user import User
from models.audit_log import AuditLog

users_bp = Blueprint("users", __name__)

VALID_ROLES = {"citizen", "authority", "admin"}


def _current_user():
    return User.query.get(get_jwt_identity())


def _require_admin(actor: User):
    if actor.role != "admin":
        return jsonify({"error": "Admin access required"}), 403
    return None


def _client_ip():
    return request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")


# ---------------------------------------------------------------------------
# GET /users/   (admin only)
# ---------------------------------------------------------------------------
@users_bp.route("/", methods=["GET"])
@jwt_required()
def list_users():
    actor = _current_user()
    err = _require_admin(actor)
    if err:
        return err

    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 20, type=int), 100)
    role = request.args.get("role")
    is_active = request.args.get("is_active")

    q = User.query
    if role:
        q = q.filter_by(role=role)
    if is_active is not None:
        q = q.filter_by(is_active=is_active.lower() == "true")

    pagination = q.order_by(User.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    return jsonify({
        "users": [u.to_dict() for u in pagination.items],
        "total": pagination.total,
        "page": pagination.page,
        "pages": pagination.pages,
        "per_page": per_page,
    })


# ---------------------------------------------------------------------------
# GET /users/<user_id>
# ---------------------------------------------------------------------------
@users_bp.route("/<int:user_id>", methods=["GET"])
@jwt_required()
def get_user(user_id: int):
    actor = _current_user()
    # Users may only view their own profile unless admin
    if actor.id != user_id and actor.role != "admin":
        return jsonify({"error": "Forbidden"}), 403

    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())


# ---------------------------------------------------------------------------
# PUT /users/<user_id>
# ---------------------------------------------------------------------------
@users_bp.route("/<int:user_id>", methods=["PUT"])
@jwt_required()
def update_user(user_id: int):
    actor = _current_user()
    if actor.id != user_id and actor.role != "admin":
        return jsonify({"error": "Forbidden"}), 403

    user = User.query.get_or_404(user_id)
    data = request.get_json(silent=True) or {}

    allowed_fields = {"name", "phone"}
    if actor.role == "admin":
        allowed_fields.update({"role", "is_active"})

    before = user.to_dict()

    for field in allowed_fields:
        if field in data:
            if field == "role" and data[field] not in VALID_ROLES:
                return jsonify({"error": f"Invalid role. Must be one of {list(VALID_ROLES)}"}), 400
            setattr(user, field, data[field])

    if "password" in data and data["password"]:
        user.set_password(data["password"])

    AuditLog.log(
        action="user.update",
        user_id=actor.id,
        ip_address=_client_ip(),
        resource_type="user",
        resource_id=user.id,
        details={"before": before, "updated_fields": list(set(data.keys()) & (allowed_fields | {"password"}))},
    )
    db.session.commit()

    return jsonify({"message": "User updated", "user": user.to_dict()})


# ---------------------------------------------------------------------------
# DELETE /users/<user_id>   (admin only)
# ---------------------------------------------------------------------------
@users_bp.route("/<int:user_id>", methods=["DELETE"])
@jwt_required()
def delete_user(user_id: int):
    actor = _current_user()
    err = _require_admin(actor)
    if err:
        return err

    if actor.id == user_id:
        return jsonify({"error": "Cannot delete your own account"}), 400

    user = User.query.get_or_404(user_id)
    user.is_active = False   # soft delete

    AuditLog.log(
        action="user.deactivate",
        user_id=actor.id,
        ip_address=_client_ip(),
        resource_type="user",
        resource_id=user.id,
    )
    db.session.commit()

    return jsonify({"message": f"User {user_id} deactivated"})


# ---------------------------------------------------------------------------
# PUT /users/<user_id>/role   (admin only)
# ---------------------------------------------------------------------------
@users_bp.route("/<int:user_id>/role", methods=["PUT"])
@jwt_required()
def change_role(user_id: int):
    actor = _current_user()
    err = _require_admin(actor)
    if err:
        return err

    user = User.query.get_or_404(user_id)
    data = request.get_json(silent=True) or {}
    new_role = data.get("role")

    if not new_role or new_role not in VALID_ROLES:
        return jsonify({"error": f"role must be one of {list(VALID_ROLES)}"}), 400

    old_role = user.role
    user.role = new_role

    AuditLog.log(
        action="user.update_role",
        user_id=actor.id,
        ip_address=_client_ip(),
        resource_type="user",
        resource_id=user.id,
        details={"old_role": old_role, "new_role": new_role},
    )
    db.session.commit()

    return jsonify({"message": "Role updated", "user": user.to_dict()})


# ---------------------------------------------------------------------------
# GET /users/<user_id>/alerts
# ---------------------------------------------------------------------------
@users_bp.route("/<int:user_id>/alerts", methods=["GET"])
@jwt_required()
def user_alerts(user_id: int):
    actor = _current_user()
    if actor.id != user_id and actor.role not in ("admin", "authority"):
        return jsonify({"error": "Forbidden"}), 403

    user = User.query.get_or_404(user_id)
    limit = min(request.args.get("limit", 50, type=int), 200)
    alerts = user.alerts.order_by(db.text("created_at desc")).limit(limit).all()

    return jsonify({
        "user_id": user_id,
        "count": len(alerts),
        "alerts": [a.to_dict() for a in alerts],
    })


# ---------------------------------------------------------------------------
# GET /users/audit-logs   (admin only)
# ---------------------------------------------------------------------------
@users_bp.route("/audit-logs", methods=["GET"])
@jwt_required()
def audit_logs():
    actor = _current_user()
    err = _require_admin(actor)
    if err:
        return err

    from models.audit_log import AuditLog

    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 50, type=int), 200)
    user_filter = request.args.get("user_id", type=int)
    action_filter = request.args.get("action")

    q = AuditLog.query
    if user_filter:
        q = q.filter_by(user_id=user_filter)
    if action_filter:
        q = q.filter(AuditLog.action.ilike(f"%{action_filter}%"))

    pagination = q.order_by(AuditLog.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    return jsonify({
        "logs": [log.to_dict() for log in pagination.items],
        "total": pagination.total,
        "page": pagination.page,
        "pages": pagination.pages,
    })
