from flask import Blueprint, jsonify, request
import pandas as pd
from datetime import datetime

domestic_bp = Blueprint("domestic", __name__)

# ---------------------------------------------------------------------------
# In-memory data store (loaded from CSV on first request)
# ---------------------------------------------------------------------------
domestic_data = None

def _load():
    global domestic_data
    if domestic_data is None:
        try:
            domestic_data = pd.read_csv("domestic_waste.csv")
        except FileNotFoundError:
            domestic_data = pd.DataFrame()   # empty — callers check .empty
    return domestic_data


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@domestic_bp.route("/zones", methods=["GET"])
def get_zones():
    df = _load()
    if df.empty:
        return jsonify({"error": "Data not loaded"}), 404
    zones = df["Zone"].unique().tolist()
    return jsonify({"zones": zones})


@domestic_bp.route("/water-quality/<zone>", methods=["GET"])
def get_water_quality(zone):
    df = _load()
    if df.empty:
        return jsonify({"error": "Data not loaded"}), 404

    zone_data = df[df["Zone"] == zone]
    if zone_data.empty:
        return jsonify({"error": f"Zone '{zone}' not found"}), 404

    latest = zone_data.iloc[-1]
    response = {
        "zone": zone,
        "BOD": float(latest.get("BOD", 0)),
        "COD": float(latest.get("COD", 0)),
        "TOC": float(latest.get("TOC", 0)),
        "date": str(latest.get("Date", "")),
        "timeline": [
            {
                "date": str(r.get("Date", "")),
                "BOD": float(r.get("BOD", 0)),
                "COD": float(r.get("COD", 0)),
                "TOC": float(r.get("TOC", 0)),
            }
            for r in zone_data.to_dict("records")
        ],
    }
    return jsonify(response)


@domestic_bp.route("/all-zones-comparison", methods=["GET"])
def get_all_zones_comparison():
    df = _load()
    if df.empty:
        return jsonify({"error": "Data not loaded"}), 404

    latest = df.loc[df.groupby("Zone")["Date"].idxmax()]
    result = [
        {
            "area": str(row["Zone"]),
            "BOD": float(row.get("BOD", 0)),
            "COD": float(row.get("COD", 0)),
            "TOC": float(row.get("TOC", 0)),
        }
        for _, row in latest.iterrows()
    ]
    return jsonify(result)


@domestic_bp.route("/upload", methods=["POST"])
def upload_csv():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    file = request.files["file"]
    if not file.filename.endswith(".csv"):
        return jsonify({"error": "Only CSV files allowed"}), 400
    try:
        global domestic_data
        domestic_data = pd.read_csv(file)
        return jsonify({"message": "File uploaded successfully", "rows": len(domestic_data)})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@domestic_bp.route("/health", methods=["GET"])
def health_check():
    return jsonify({"status": "ok", "service": "domestic_waste"})
