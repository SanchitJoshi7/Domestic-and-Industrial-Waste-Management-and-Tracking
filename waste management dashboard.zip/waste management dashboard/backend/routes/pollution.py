from flask import Blueprint, jsonify, request
import pandas as pd

pollution_bp = Blueprint("pollution", __name__)

# ---------------------------------------------------------------------------
# In-memory data store
# ---------------------------------------------------------------------------
pollution_data = None

def _load():
    global pollution_data
    if pollution_data is None:
        try:
            pollution_data = pd.read_csv("pollution_zones.csv")
        except FileNotFoundError:
            pollution_data = pd.DataFrame()
    return pollution_data


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@pollution_bp.route("/zones", methods=["GET"])
def get_pollution_zones():
    df = _load()
    if df.empty:
        return jsonify({"error": "Data not loaded"}), 404

    zones = [
        {
            "id":        str(row.get("Zone_ID", "")),
            "name":      str(row.get("Zone_Name", "")),
            "level":     float(row.get("Pollution_Level", 0)),
            "latitude":  float(row.get("Latitude", 0)),
            "longitude": float(row.get("Longitude", 0)),
            "zone_type": str(row.get("Type", "")),
        }
        for _, row in df.iterrows()
    ]
    return jsonify(zones)


@pollution_bp.route("/zone/<zone_id>", methods=["GET"])
def get_zone_details(zone_id):
    df = _load()
    if df.empty:
        return jsonify({"error": "Data not loaded"}), 404

    zone_data = df[df["Zone_ID"] == zone_id]
    if zone_data.empty:
        return jsonify({"error": f"Zone '{zone_id}' not found"}), 404

    row = zone_data.iloc[0]
    return jsonify({
        "id":        str(row.get("Zone_ID", "")),
        "name":      str(row.get("Zone_Name", "")),
        "level":     float(row.get("Pollution_Level", 0)),
        "latitude":  float(row.get("Latitude", 0)),
        "longitude": float(row.get("Longitude", 0)),
        "type":      str(row.get("Type", "")),
        "pollutants": {
            "pm25": float(row.get("PM25", 0)),
            "pm10": float(row.get("PM10", 0)),
            "no2":  float(row.get("NO2", 0)),
            "so2":  float(row.get("SO2", 0)),
        },
        "last_updated": str(row.get("Last_Updated", "")),
    })


@pollution_bp.route("/pollutants/<zone_id>", methods=["GET"])
def get_zone_pollutants(zone_id):
    df = _load()
    if df.empty:
        return jsonify({"error": "Data not loaded"}), 404

    zone_data = df[df["Zone_ID"] == zone_id]
    if zone_data.empty:
        return jsonify({"error": "Zone not found"}), 404

    row = zone_data.iloc[0]

    def status(val, bad, moderate):
        return "bad" if val > bad else "moderate" if val > moderate else "good"

    return jsonify({
        "pm25": {"value": float(row.get("PM25", 0)), "unit": "µg/m³", "name": "Fine Particulate Matter",
                 "status": status(float(row.get("PM25", 0)), 100, 50)},
        "pm10": {"value": float(row.get("PM10", 0)), "unit": "µg/m³", "name": "Particulate Matter",
                 "status": status(float(row.get("PM10", 0)), 200, 100)},
        "no2":  {"value": float(row.get("NO2",  0)), "unit": "ppb",   "name": "Nitrogen Dioxide",
                 "status": status(float(row.get("NO2",  0)), 150, 80)},
        "so2":  {"value": float(row.get("SO2",  0)), "unit": "ppb",   "name": "Sulfur Dioxide",
                 "status": status(float(row.get("SO2",  0)), 200, 100)},
    })


@pollution_bp.route("/aqi", methods=["GET"])
def get_aqi_data():
    df = _load()
    if df.empty:
        return jsonify({"error": "Data not loaded"}), 404

    def category(level):
        if level > 400: return "Severe"
        if level > 300: return "Very Poor"
        if level > 200: return "Poor"
        if level > 100: return "Moderate"
        return "Satisfactory"

    return jsonify([
        {"zone": str(row.get("Zone_Name", "")),
         "aqi_value": float(row.get("Pollution_Level", 0)),
         "category": category(float(row.get("Pollution_Level", 0)))}
        for _, row in df.iterrows()
    ])


@pollution_bp.route("/heatmap", methods=["GET"])
def get_heatmap_data():
    df = _load()
    if df.empty:
        return jsonify({"error": "Data not loaded"}), 404

    return jsonify([
        {
            "lat":       float(row.get("Latitude", 0)),
            "lng":       float(row.get("Longitude", 0)),
            "intensity": float(row.get("Pollution_Level", 0)) / 400,
            "zone_name": str(row.get("Zone_Name", "")),
        }
        for _, row in df.iterrows()
    ])


@pollution_bp.route("/upload", methods=["POST"])
def upload_pollution_csv():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    file = request.files["file"]
    if not file.filename.endswith(".csv"):
        return jsonify({"error": "Only CSV files allowed"}), 400
    try:
        global pollution_data
        pollution_data = pd.read_csv(file)
        return jsonify({"message": "Pollution data uploaded", "rows": len(pollution_data),
                        "columns": list(pollution_data.columns)})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@pollution_bp.route("/health", methods=["GET"])
def health_check():
    return jsonify({"status": "ok", "service": "pollution"})
