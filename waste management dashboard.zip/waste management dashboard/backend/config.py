import os
from pathlib import Path
from datetime import timedelta

# ---------------------------------------------------------------------------
# Load .env from  <project_root>/database/.env
# ---------------------------------------------------------------------------
try:
    from dotenv import load_dotenv

    # Resolve path relative to this file:  backend/ -> project_root/ -> database/.env
    _env_path = Path(__file__).resolve().parent.parent / "database" / ".env"
    if _env_path.exists():
        load_dotenv(dotenv_path=_env_path)
        print(f"[config] Loaded environment from {_env_path}")
    else:
        print(f"[config] WARNING: .env not found at {_env_path}. "
              "Copy database/.env.example to database/.env and fill in your values.")
except ImportError:
    print("[config] WARNING: python-dotenv not installed. "
          "Run: pip install python-dotenv")


class Config:
    """Base configuration."""
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-in-production")
    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", "jwt-secret-key-change-in-production")
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=30)

    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", "sqlite:///ecowatch.db"
    )

    # Pagination
    DEFAULT_PAGE_SIZE = 20
    MAX_PAGE_SIZE = 100

    # File uploads
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB
    ALLOWED_EXTENSIONS = {"csv"}

    # CORS
    CORS_ORIGINS = os.environ.get("CORS_ORIGINS", "*")


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL", "postgresql://user:pass@localhost/ecowatch")


class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"


config_map = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
}

def get_config():
    env = os.environ.get("FLASK_ENV", "development")
    return config_map.get(env, DevelopmentConfig)
