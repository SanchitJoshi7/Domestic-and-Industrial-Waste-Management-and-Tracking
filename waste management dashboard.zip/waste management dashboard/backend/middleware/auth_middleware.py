from functools import wraps
from flask import request, jsonify
from typing import Callable, Dict, Optional, Tuple
from datetime import datetime

class AuthMiddleware:
    def __init__(self, auth_service):
        self.auth_service = auth_service

    def token_required(self, f: Callable) -> Callable:
        """Decorator to require valid JWT token"""
        @wraps(f)
        def decorated(*args, **kwargs):
            token = None
            
            # Check for token in headers
            if 'Authorization' in request.headers:
                auth_header = request.headers['Authorization']
                try:
                    token = auth_header.split(' ')[1]
                except IndexError:
                    return jsonify({'message': 'Invalid token format'}), 401
            
            if not token:
                return jsonify({'message': 'Token is missing'}), 401
            
            # Verify token
            is_valid, payload = self.auth_service.verify_token(token)
            
            if not is_valid:
                return jsonify({'message': 'Token is invalid or expired'}), 401
            
            # Add user info to request context
            request.user = payload
            
            return f(*args, **kwargs)
        
        return decorated

    def admin_required(self, f: Callable) -> Callable:
        """Decorator to require admin privileges"""
        @wraps(f)
        def decorated(*args, **kwargs):
            token = None
            
            if 'Authorization' in request.headers:
                auth_header = request.headers['Authorization']
                try:
                    token = auth_header.split(' ')[1]
                except IndexError:
                    return jsonify({'message': 'Invalid token format'}), 401
            
            if not token:
                return jsonify({'message': 'Token is missing'}), 401
            
            is_valid, payload = self.auth_service.verify_token(token)
            
            if not is_valid:
                return jsonify({'message': 'Token is invalid or expired'}), 401
            
            if not payload.get('is_admin'):
                return jsonify({'message': 'Admin privileges required'}), 403
            
            request.user = payload
            
            return f(*args, **kwargs)
        
        return decorated

    def refresh_token_required(self, f: Callable) -> Callable:
        """Decorator to require valid refresh token"""
        @wraps(f)
        def decorated(*args, **kwargs):
            data = request.get_json()
            
            if not data or 'refresh_token' not in data:
                return jsonify({'message': 'Refresh token is missing'}), 400
            
            refresh_token = data['refresh_token']
            
            new_token = self.auth_service.refresh_access_token(refresh_token)
            
            if not new_token:
                return jsonify({'message': 'Invalid refresh token'}), 401
            
            request.new_token = new_token
            
            return f(*args, **kwargs)
        
        return decorated
