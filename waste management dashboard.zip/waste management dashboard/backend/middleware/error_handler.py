from flask import jsonify
from typing import Tuple, Type, Dict
from datetime import datetime
import traceback
import logging

logger = logging.getLogger(__name__)

class ErrorHandler:
    def __init__(self, app=None):
        self.app = app
        if app:
            self.init_app(app)

    def init_app(self, app):
        """Initialize error handlers with Flask app"""
        self.app = app
        
        @app.errorhandler(400)
        def bad_request(error):
            return self._format_error('Bad Request', 400, str(error))
        
        @app.errorhandler(401)
        def unauthorized(error):
            return self._format_error('Unauthorized', 401, 'Authentication required')
        
        @app.errorhandler(403)
        def forbidden(error):
            return self._format_error('Forbidden', 403, 'Access denied')
        
        @app.errorhandler(404)
        def not_found(error):
            return self._format_error('Not Found', 404, 'Resource not found')
        
        @app.errorhandler(405)
        def method_not_allowed(error):
            return self._format_error('Method Not Allowed', 405, 'HTTP method not allowed')
        
        @app.errorhandler(500)
        def internal_error(error):
            logger.error(f"Internal Server Error: {str(error)}\n{traceback.format_exc()}")
            return self._format_error('Internal Server Error', 500, 'An unexpected error occurred')
        
        @app.errorhandler(Exception)
        def handle_exception(error):
            logger.error(f"Unhandled Exception: {str(error)}\n{traceback.format_exc()}")
            return self._format_error('Server Error', 500, 'An unexpected error occurred')

    @staticmethod
    def _format_error(error_type: str, status_code: int, message: str) -> Tuple[Dict, int]:
        """Format error response"""
        return jsonify({
            'status': 'error',
            'error_type': error_type,
            'message': message,
            'timestamp': datetime.utcnow().isoformat(),
            'status_code': status_code
        }), status_code

    @staticmethod
    def handle_validation_error(errors: Dict) -> Tuple[Dict, int]:
        """Handle validation errors"""
        return jsonify({
            'status': 'error',
            'error_type': 'Validation Error',
            'message': 'Request validation failed',
            'errors': errors,
            'timestamp': datetime.utcnow().isoformat()
        }), 400

    @staticmethod
    def handle_database_error(error: Exception) -> Tuple[Dict, int]:
        """Handle database errors"""
        logger.error(f"Database Error: {str(error)}")
        return jsonify({
            'status': 'error',
            'error_type': 'Database Error',
            'message': 'An error occurred while accessing the database',
            'timestamp': datetime.utcnow().isoformat()
        }), 500

    @staticmethod
    def handle_auth_error(message: str = 'Authentication failed') -> Tuple[Dict, int]:
        """Handle authentication errors"""
        return jsonify({
            'status': 'error',
            'error_type': 'Authentication Error',
            'message': message,
            'timestamp': datetime.utcnow().isoformat()
        }), 401

    @staticmethod
    def handle_permission_error(message: str = 'Permission denied') -> Tuple[Dict, int]:
        """Handle permission errors"""
        return jsonify({
            'status': 'error',
            'error_type': 'Permission Error',
            'message': message,
            'timestamp': datetime.utcnow().isoformat()
        }), 403

    @staticmethod
    def handle_not_found_error(resource: str = 'Resource') -> Tuple[Dict, int]:
        """Handle not found errors"""
        return jsonify({
            'status': 'error',
            'error_type': 'Not Found',
            'message': f'{resource} not found',
            'timestamp': datetime.utcnow().isoformat()
        }), 404

    @staticmethod
    def handle_conflict_error(message: str) -> Tuple[Dict, int]:
        """Handle conflict errors (duplicate, etc.)"""
        return jsonify({
            'status': 'error',
            'error_type': 'Conflict',
            'message': message,
            'timestamp': datetime.utcnow().isoformat()
        }), 409

    @staticmethod
    def handle_rate_limit_error() -> Tuple[Dict, int]:
        """Handle rate limit errors"""
        return jsonify({
            'status': 'error',
            'error_type': 'Rate Limit Exceeded',
            'message': 'Too many requests. Please try again later.',
            'timestamp': datetime.utcnow().isoformat()
        }), 429

    @staticmethod
    def log_error(error_type: str, message: str, context: Dict = None):
        """Log error with context"""
        log_message = f"[{error_type}] {message}"
        if context:
            log_message += f" | Context: {context}"
        logger.error(log_message)
