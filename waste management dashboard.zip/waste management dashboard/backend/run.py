"""
run.py — Start the Waste Management backend server.

Usage:
    python run.py              (or double-click in file explorer)
"""
import sys
import os

# Make sure we can import sibling modules when run from any directory
sys.path.insert(0, os.path.dirname(__file__))

try:
    from app import create_app
except ImportError as e:
    print("\n[ERROR] Missing dependencies. Run this first:")
    print("    pip install -r requirements.txt\n")
    print(f"Details: {e}")
    input("Press Enter to exit...")
    sys.exit(1)

if __name__ == "__main__":
    host = os.environ.get("BACKEND_HOST", "localhost")
    port = int(os.environ.get("BACKEND_PORT", 5000))

    print("\n" + "="*50)
    print("  Waste Management Dashboard — Backend")
    print("="*50)
    print(f"  Server : http://{host}:{port}")
    print(f"  Health : http://{host}:{port}/health")
    print("  Press Ctrl+C to stop")
    print("="*50 + "\n")

    app = create_app()
    app.run(host=host, port=port, debug=True, use_reloader=False)
