import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, List, Optional
import os
from datetime import datetime

class EmailService:
    def __init__(self):
        self.smtp_server = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
        self.smtp_port = int(os.getenv('SMTP_PORT', 587))
        self.sender_email = os.getenv('SENDER_EMAIL', 'noreply@wastemanagement.com')
        self.sender_password = os.getenv('SENDER_PASSWORD', '')
        self.sender_name = os.getenv('SENDER_NAME', 'Waste Management System')

    def send_email(self, to: str, subject: str, body: str, 
                   html: Optional[str] = None, cc: Optional[List[str]] = None) -> Dict:
        """Send email with optional HTML content"""
        try:
            message = MIMEMultipart('alternative')
            message['Subject'] = subject
            message['From'] = f"{self.sender_name} <{self.sender_email}>"
            message['To'] = to
            
            if cc:
                message['Cc'] = ', '.join(cc)
            
            # Attach plain text
            text_part = MIMEText(body, 'plain')
            message.attach(text_part)
            
            # Attach HTML if provided
            if html:
                html_part = MIMEText(html, 'html')
                message.attach(html_part)
            
            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                
                recipients = [to] + (cc or [])
                server.sendmail(self.sender_email, recipients, message.as_string())
            
            return {
                'status': 'success',
                'message': f'Email sent to {to}',
                'timestamp': datetime.utcnow().isoformat()
            }
        except smtplib.SMTPAuthenticationError:
            return {
                'status': 'error',
                'message': 'SMTP authentication failed',
                'timestamp': datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }

    def send_alert_notification(self, authority_email: str, alert_data: Dict) -> Dict:
        """Send alert notification email to authority"""
        subject = f"New Environmental Alert - {alert_data.get('alert_id')}"
        
        body = f"""
        New Alert Submission

        Alert ID: {alert_data.get('alert_id')}
        Submitted By: {alert_data.get('user_name')}
        Email: {alert_data.get('user_email')}
        Phone: {alert_data.get('user_phone')}

        Location: {alert_data.get('address')}
        Message: {alert_data.get('message')}

        Priority: {alert_data.get('priority', 'Medium')}
        Submitted At: {alert_data.get('submitted_at')}

        Please log in to the dashboard to take action on this alert.
        """
        
        html = f"""
        <html>
            <body>
                <h2>New Environmental Alert</h2>
                <p><strong>Alert ID:</strong> {alert_data.get('alert_id')}</p>
                <p><strong>Submitted By:</strong> {alert_data.get('user_name')}</p>
                <p><strong>Email:</strong> {alert_data.get('user_email')}</p>
                <p><strong>Phone:</strong> {alert_data.get('user_phone')}</p>
                <hr>
                <p><strong>Location:</strong> {alert_data.get('address')}</p>
                <p><strong>Message:</strong> {alert_data.get('message')}</p>
                <p><strong>Priority:</strong> {alert_data.get('priority', 'Medium')}</p>
                <p><strong>Submitted:</strong> {alert_data.get('submitted_at')}</p>
                <hr>
                <p><a href="https://yourdomain.com/dashboard/alerts">View in Dashboard</a></p>
            </body>
        </html>
        """
        
        return self.send_email(authority_email, subject, body, html)

    def send_alert_confirmation(self, user_email: str, alert_id: str, 
                               authority_name: str) -> Dict:
        """Send confirmation email to user"""
        subject = f"Alert Submitted Successfully - {alert_id}"
        
        body = f"""
        Your alert has been submitted successfully!

        Alert ID: {alert_id}
        Submitted To: {authority_name}
        Time: {datetime.utcnow().isoformat()}

        You can track the status of your alert using the alert ID above.
        We will keep you updated on the status of your submission.

        Thank you for helping keep our environment clean!
        """
        
        html = f"""
        <html>
            <body>
                <h2>Alert Submitted Successfully</h2>
                <p>Your alert has been received and forwarded to the relevant authority.</p>
                <p><strong>Alert ID:</strong> <code>{alert_id}</code></p>
                <p><strong>Authority:</strong> {authority_name}</p>
                <p><strong>Submitted:</strong> {datetime.utcnow().isoformat()}</p>
                <hr>
                <p><a href="https://yourdomain.com/dashboard/alerts">Track Your Alert</a></p>
                <p>Thank you for your contribution!</p>
            </body>
        </html>
        """
        
        return self.send_email(user_email, subject, body, html)

    def send_status_update(self, user_email: str, alert_id: str, 
                          status: str, notes: Optional[str] = None) -> Dict:
        """Send alert status update email"""
        subject = f"Alert Status Update - {alert_id}"
        
        status_message = {
            'submitted': 'Your alert has been submitted and is awaiting review.',
            'acknowledged': 'Your alert has been acknowledged by the authority.',
            'processing': 'Your alert is being processed.',
            'resolved': 'Your alert has been resolved.',
            'rejected': 'Your alert could not be processed.'
        }
        
        body = f"""
        Alert Status Update

        Alert ID: {alert_id}
        Current Status: {status.upper()}
        Updated At: {datetime.utcnow().isoformat()}

        {status_message.get(status, 'Status updated')}

        {f'Notes: {notes}' if notes else ''}
        """
        
        html = f"""
        <html>
            <body>
                <h2>Alert Status Update</h2>
                <p><strong>Alert ID:</strong> {alert_id}</p>
                <p><strong>Status:</strong> <strong style="color: #16a34a;">{status.upper()}</strong></p>
                <p>{status_message.get(status, 'Status updated')}</p>
                {f'<p><strong>Notes:</strong> {notes}</p>' if notes else ''}
                <hr>
                <p><a href="https://yourdomain.com/dashboard/alerts">View Full Details</a></p>
            </body>
        </html>
        """
        
        return self.send_email(user_email, subject, body, html)

    def send_daily_summary(self, user_email: str, summary_data: Dict) -> Dict:
        """Send daily pollution summary email"""
        subject = f"Daily Pollution Summary - {datetime.utcnow().date()}"
        
        body = f"""
        Daily Pollution Summary

        Air Quality: {summary_data.get('air_quality', 'N/A')}
        Waste Status: {summary_data.get('waste_status', 'N/A')}
        Active Alerts: {summary_data.get('active_alerts', 0)}

        Check the dashboard for detailed information.
        """
        
        return self.send_email(user_email, subject, body)

    def send_bulk_email(self, recipients: List[str], subject: str, 
                       body: str, html: Optional[str] = None) -> Dict:
        """Send bulk email to multiple recipients"""
        successful = 0
        failed = 0
        errors = []
        
        for recipient in recipients:
            result = self.send_email(recipient, subject, body, html)
            if result['status'] == 'success':
                successful += 1
            else:
                failed += 1
                errors.append({'recipient': recipient, 'error': result['message']})
        
        return {
            'status': 'completed',
            'successful': successful,
            'failed': failed,
            'errors': errors,
            'timestamp': datetime.utcnow().isoformat()
        }

    def send_password_reset_email(self, user_email: str, reset_token: str, 
                                  user_name: str) -> Dict:
        """Send password reset email"""
        reset_link = f"https://yourdomain.com/reset-password?token={reset_token}"
        
        subject = "Password Reset Request"
        
        body = f"""
        Hi {user_name},

        Click the link below to reset your password:
        {reset_link}

        This link expires in 1 hour.
        
        If you did not request this, please ignore this email.
        """
        
        html = f"""
        <html>
            <body>
                <h2>Password Reset Request</h2>
                <p>Hi {user_name},</p>
                <p><a href="{reset_link}" style="background: #3b82f6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Reset Password</a></p>
                <p>This link expires in 1 hour.</p>
            </body>
        </html>
        """
        
        return self.send_email(user_email, subject, body, html)
