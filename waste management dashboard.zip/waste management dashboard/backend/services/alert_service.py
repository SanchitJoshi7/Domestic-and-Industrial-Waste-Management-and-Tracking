from datetime import datetime
from typing import Dict, List, Optional
from enum import Enum

class AlertStatus(Enum):
    SUBMITTED = "submitted"
    ACKNOWLEDGED = "acknowledged"
    PROCESSING = "processing"
    RESOLVED = "resolved"
    REJECTED = "rejected"

class AlertPriority(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class AlertService:
    def __init__(self, db_connection=None, email_service=None):
        self.db = db_connection
        self.email_service = email_service

    def create_alert(self, alert_data: Dict) -> Dict:
        """Create new alert submission"""
        try:
            if not self._validate_alert_data(alert_data):
                return {'status': 'error', 'message': 'Invalid alert data'}
            
            alert_id = self._generate_alert_id()
            
            query = """
                INSERT INTO alerts 
                (id, user_id, authority_id, message, address, status, priority, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            priority = self._determine_priority(alert_data)
            
            # Execute insert through db
            
            # Send email notification
            if self.email_service:
                self._send_alert_notification(alert_data, alert_id)
            
            return {
                'status': 'success',
                'alert_id': alert_id,
                'message': 'Alert submitted successfully'
            }
        except Exception as e:
            return {'status': 'error', 'message': str(e)}

    def get_user_alerts(self, user_id: str, limit: int = 50) -> List[Dict]:
        """Get all alerts submitted by user"""
        try:
            query = """
                SELECT id, authority_id, message, address, status, 
                       priority, created_at, updated_at
                FROM alerts
                WHERE user_id = %s
                ORDER BY created_at DESC
                LIMIT %s
            """
            # Execute query through db
            return []
        except Exception as e:
            return []

    def get_all_alerts(self, authority_id: Optional[str] = None, 
                      status: Optional[str] = None) -> List[Dict]:
        """Get alerts for authority or all alerts"""
        try:
            query = "SELECT * FROM alerts WHERE 1=1"
            params = []
            
            if authority_id:
                query += " AND authority_id = %s"
                params.append(authority_id)
            
            if status:
                query += " AND status = %s"
                params.append(status)
            
            query += " ORDER BY created_at DESC LIMIT 100"
            
            # Execute query through db
            return []
        except Exception as e:
            return []

    def update_alert_status(self, alert_id: str, new_status: str, 
                           notes: Optional[str] = None) -> Dict:
        """Update alert status"""
        try:
            if new_status not in [status.value for status in AlertStatus]:
                return {'status': 'error', 'message': 'Invalid status'}
            
            query = """
                UPDATE alerts 
                SET status = %s, updated_at = %s
                WHERE id = %s
            """
            
            # Execute update through db
            
            if new_status == AlertStatus.RESOLVED.value:
                query_resolve = """
                    UPDATE alerts 
                    SET resolved_at = %s
                    WHERE id = %s
                """
                # Execute update
            
            return {
                'status': 'success',
                'message': 'Alert status updated'
            }
        except Exception as e:
            return {'status': 'error', 'message': str(e)}

    def get_alert_statistics(self) -> Dict:
        """Get alert statistics"""
        try:
            query = """
                SELECT 
                    COUNT(*) as total_alerts,
                    SUM(CASE WHEN status = 'submitted' THEN 1 ELSE 0 END) as pending,
                    SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) as resolved,
                    AVG(EXTRACT(EPOCH FROM (resolved_at - created_at))/3600) as avg_resolution_hours
                FROM alerts
            """
            # Execute query through db
            return {
                'total_alerts': 0,
                'pending': 0,
                'resolved': 0
            }
        except Exception as e:
            return {'error': str(e)}

    def get_alerts_by_authority(self, authority_id: str) -> Dict:
        """Get alerts submitted to specific authority"""
        try:
            query = """
                SELECT 
                    id, user_id, message, address, status, priority, created_at
                FROM alerts
                WHERE authority_id = %s
                ORDER BY created_at DESC
                LIMIT 50
            """
            # Execute query through db
            return {'alerts': []}
        except Exception as e:
            return {'error': str(e)}

    def _validate_alert_data(self, data: Dict) -> bool:
        """Validate alert data"""
        required_fields = ['user_id', 'authority_id', 'message', 'address']
        return all(field in data for field in required_fields)

    def _determine_priority(self, alert_data: Dict) -> str:
        """Determine alert priority based on content"""
        message = alert_data.get('message', '').lower()
        
        critical_keywords = ['hazardous', 'emergency', 'immediate', 'critical']
        high_keywords = ['pollution', 'contamination', 'illegal', 'severe']
        
        for keyword in critical_keywords:
            if keyword in message:
                return AlertPriority.CRITICAL.value
        
        for keyword in high_keywords:
            if keyword in message:
                return AlertPriority.HIGH.value
        
        return AlertPriority.MEDIUM.value

    def _generate_alert_id(self) -> str:
        """Generate unique alert ID"""
        import uuid
        return f"ALERT-{uuid.uuid4().hex[:10].upper()}"

    def _send_alert_notification(self, alert_data: Dict, alert_id: str) -> bool:
        """Send email notification to authority"""
        try:
            authority_id = alert_data.get('authority_id')
            
            subject = f"New Environmental Alert - {alert_id}"
            body = f"""
            Alert ID: {alert_id}
            Location: {alert_data.get('address')}
            Message: {alert_data.get('message')}
            Submitted: {datetime.utcnow().isoformat()}
            """
            
            # Use email service to send
            if self.email_service:
                self.email_service.send_email(
                    to=alert_data.get('authority_email'),
                    subject=subject,
                    body=body
                )
            
            return True
        except Exception as e:
            print(f"Error sending notification: {str(e)}")
            return False

    def delete_alert(self, alert_id: str) -> Dict:
        """Delete alert (soft delete)"""
        try:
            # Archive instead of delete
            query = """
                UPDATE alerts 
                SET status = 'archived'
                WHERE id = %s
            """
            # Execute update through db
            return {'status': 'success', 'message': 'Alert archived'}
        except Exception as e:
            return {'status': 'error', 'message': str(e)}
