from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager

from config import get_config
from models import db

# --- Route blueprints ---
from routes.auth import auth_bp
from routes.sensors import sensors_bp
from routes.users import users_bp
from routes.alerts import alerts_bp
from routes.domestic import domestic_bp
from routes.industrial import industrial_bp
from routes.pollution import pollution_bp


def create_app(config=None):
    app = Flask(__name__)
    app.config.from_object(config or get_config())

    # Extensions
    CORS(app, origins=app.config.get("CORS_ORIGINS", "*"))
    db.init_app(app)
    JWTManager(app)

    # Register blueprints
    app.register_blueprint(auth_bp,       url_prefix="/auth")
    app.register_blueprint(sensors_bp,    url_prefix="/sensors")
    app.register_blueprint(users_bp,      url_prefix="/users")
    app.register_blueprint(alerts_bp,     url_prefix="/alerts")
    app.register_blueprint(domestic_bp,   url_prefix="/domestic")
    app.register_blueprint(industrial_bp, url_prefix="/industrial")
    app.register_blueprint(pollution_bp,  url_prefix="/pollution")

    # Create tables on first run (dev convenience)
    with app.app_context():
        db.create_all()

    @app.route("/health")
    def health():
        return {"status": "ok", "service": "ecowatch-backend"}

    return app


if __name__ == "__main__":
    app = create_app()
    print("\n==================================================")
    print("  Waste Management Dashboard — Backend")
    print("==================================================")
    print("  Server : http://localhost:5000")
    print("  Health : http://localhost:5000/health")
    print("  Press Ctrl+C to stop")
    print("==================================================\n")
    app.run(host='0.0.0.0', port=5000, debug=True)
