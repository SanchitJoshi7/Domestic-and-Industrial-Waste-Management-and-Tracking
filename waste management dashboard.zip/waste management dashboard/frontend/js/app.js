// Initialize when page loads
window.addEventListener('load', () => {
    // Load all data first, then render the active tab
    Promise.all([
        loadDomesticData(),
        loadIndustrialData(),
        loadPollutionData(),
        loadAuthorities()
    ]).then(() => {
        // Set selectedZone now that pollution data is loaded
        if (pollutionZones && pollutionZones.length > 0) {
            selectedZone = pollutionZones[0];
        }
        // Render the active tab
        const activeTab = document.querySelector('.tab-trigger.active');
        if (activeTab) {
            const tabName = activeTab.getAttribute('data-tab');
            switchTab(tabName);
        } else {
            renderDomestic();
        }
    });

    // Set up tab listeners
    setupTabListeners();
});

function setupTabListeners() {
    document.querySelectorAll('.tab-trigger').forEach(button => {
        button.addEventListener('click', (e) => {
            const tabName = e.target.getAttribute('data-tab');
            switchTab(tabName);
        });
    });
}

function switchTab(tabName) {
    // Update active button
    document.querySelectorAll('.tab-trigger').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    // Update active content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(tabName).classList.add('active');
    
    // Render appropriate content
    switch(tabName) {
        case 'domestic':
            renderDomestic();
            break;
        case 'industrial':
            renderIndustrial();
            break;
        case 'pollution':
            renderPollution();
            break;
        case 'alert':
            renderAlert();
            break;
    }
}
