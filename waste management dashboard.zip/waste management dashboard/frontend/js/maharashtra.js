const maharashtraData = {
    'Pune': {
        talukas: ['Pune', 'Ambegaon', 'Baramati', 'Bhor', 'Indapur', 'Junnar', 'Khed', 'Koregaon', 'Mulshi', 'Shipur', 'Talegaon']
    },
    'Mumbai': {
        talukas: ['Mumbai', 'Ambernath', 'Kalyan', 'Thane', 'Vasai']
    },
    'Nagpur': {
        talukas: ['Nagpur', 'Bhandara', 'Gondia', 'Wardha', 'Yavatmal']
    },
    'Aurangabad': {
        talukas: ['Aurangabad', 'Kannad', 'Khuldabad', 'Sillod', 'Vairat', 'Paithan', 'Phulambri']
    },
    'Nashik': {
        talukas: ['Nashik', 'Baglan', 'Chandwad', 'Dindori', 'Igatpuri', 'Malegaon', 'Nandgaon', 'Nevasa', 'Peth', 'Satpur', 'Sinnar', 'Surgana', 'Trimbak', 'Yeola']
    },
    'Satara': {
        talukas: ['Satara', 'Jawali', 'Koregaon', 'Khandala', 'Mahabaleshwar', 'Phaltan', 'Wai', 'Kadegaon']
    },
    'Solapur': {
        talukas: ['Solapur', 'Akkalkot', 'Barshi', 'Karmala', 'Madha', 'Mangalwedha', 'Malshiras', 'Pandharpur']
    },
    'Kolhapur': {
        talukas: ['Kolhapur', 'Ajra', 'Bavda', 'Bhudargad', 'Chandgad', 'Gaganbavada', 'Hatkanangale', 'Ichalkaranji', 'Karveer', 'Panhala', 'Radhannagari', 'Shirol', 'Vaibhavwadi']
    },
    'Sangli': {
        talukas: ['Sangli', 'Jat', 'Kadegaon', 'Khanapur', 'Miraj', 'Tasgaon', 'Vishalgarh']
    },
    'Ratnagiri': {
        talukas: ['Ratnagiri', 'Chiplun', 'Dapoli', 'Guhagar', 'Khed', 'Rajapur', 'Sangameshwar']
    },
    'Sindhudurg': {
        talukas: ['Sindhudurg', 'Devgad', 'Dodamarg', 'Kudal', 'Sawantwadi', 'Vaibhavwadi']
    },
    'Thane': {
        talukas: ['Thane', 'Ambarnath', 'Dombivali', 'Kalyan', 'Mulund', 'Navi Mumbai', 'Ulhasnagar', 'Vasai', 'Virar']
    },
    'Raigad': {
        talukas: ['Raigad', 'Alibaug', 'Khalapur', 'Mahad', 'Mangaon', 'Mhasla', 'Panvel', 'Poladpur', 'Roha', 'Shrivardhan', 'Sudhagad', 'Uran']
    },
    'Buldhana': {
        talukas: ['Buldhana', 'Chikhli', 'Khamgaon', 'Motala', 'Shegaon']
    },
    'Akola': {
        talukas: ['Akola', 'Akot', 'Balapur', 'Barshitakli', 'Murtajapur', 'Patur']
    },
    'Washim': {
        talukas: ['Washim', 'Karanja', 'Malegaon', 'Mangrulpir', 'Risod']
    },
    'Amravati': {
        talukas: ['Amravati', 'Achalpur', 'Anjangaon', 'Chandur Railway', 'Daryapur', 'Dharni', 'Morshi', 'Tiosa']
    },
    'Jalna': {
        talukas: ['Jalna', 'Ambad', 'Ghansawangi', 'Parli Vaijnath', 'Bhokardan']
    },
    'Parbhani': {
        talukas: ['Parbhani', 'Gangakhed', 'Pathardi', 'Purna', 'Sillod', 'Sonpeth']
    },
    'Latur': {
        talukas: ['Latur', 'Ausa', 'Deoni', 'Nilanga', 'Renapur', 'Shirur Anantpal', 'Vikarabad']
    },
    'Beed': {
        talukas: ['Beed', 'Ashti', 'Beedkhurd', 'Georai', 'Kada', 'Latur', 'Patoda', 'Shirur', 'Sonpeth']
    },
    'Nanded': {
        talukas: ['Nanded', 'Ardhapur', 'Bhokar', 'Biloli', 'Deglur', 'Kandhar', 'Kinwat', 'Loha', 'Mudkhed', 'Naigaon', 'Umri']
    },
    'Ahmednagar': {
        talukas: ['Ahmednagar', 'Akola', 'Akoli', 'Chandwad', 'Jamkhed', 'Nagar', 'Newasa', 'Parner', 'Pathardi', 'Rahuri', 'Sangamner', 'Sinnar', 'Shrigonda']
    },
    'Dhule': {
        talukas: ['Dhule', 'Dondaicha', 'Khultabad', 'Sakri', 'Sindkheda']
    },
    'Nandurbar': {
        talukas: ['Nandurbar', 'Akkalkuwa', 'Dadegaon', 'Nawapur', 'Taloda']
    },
    'Jalgaon': {
        talukas: ['Jalgaon', 'Amod', 'Bhusawal', 'Bodwad', 'Chopda', 'Erandol', 'Jamod', 'Muktainagar', 'Pachora', 'Parola', 'Raver', 'Yawal']
    },
    'Wardha': {
        talukas: ['Wardha', 'Arvi', 'Hinganghat', 'Seloo', 'Wardha']
    },
    'Yavatmal': {
        talukas: ['Yavatmal', 'Darwha', 'Digras', 'Ghatanji', 'Ner', 'Pandharkawada', 'Pusad', 'Umarkhed', 'Wani', 'Yelgaon']
    },
    'Hingoli': {
        talukas: ['Hingoli', 'Basmath', 'Sengaon', 'Aundha Nagnath']
    }
};
