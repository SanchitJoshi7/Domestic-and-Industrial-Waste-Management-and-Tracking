// =============================================================================
//  auth.js — Backend-integrated authentication
//  Credentials are stored in the database (via backend API), not localStorage.
//  Session tokens are kept in sessionStorage for the current tab only.
// =============================================================================

const BACKEND_URL = 'http://localhost:5000';
const SESSION_KEY  = 'currentUser';
const TOKEN_KEY    = 'accessToken';
let profileMenuInitialized = false;

// ---------------------------------------------------------------------------
//  Token / session helpers
// ---------------------------------------------------------------------------
function saveSession(user, token) {
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
    sessionStorage.setItem(TOKEN_KEY, token);
}

function clearSession() {
    sessionStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(TOKEN_KEY);
}

function getCurrentUser() {
    const raw = sessionStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
}

function getToken() {
    return sessionStorage.getItem(TOKEN_KEY);
}

function isAuthenticated() {
    return !!(getToken() && getCurrentUser());
}

// ---------------------------------------------------------------------------
//  API helpers
// ---------------------------------------------------------------------------
async function apiPost(path, body) {
    const res = await fetch(`${BACKEND_URL}${path}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok, status: res.status, data };
}

// ---------------------------------------------------------------------------
//  Auth actions
// ---------------------------------------------------------------------------
async function apiLogin(email, password) {
    try {
        const { ok, data } = await apiPost('/auth/login', { email, password });
        if (ok && data.access_token) {
            saveSession(data.user, data.access_token);
            return { success: true, user: data.user };
        }
        return { success: false, message: data.error || 'Login failed' };
    } catch {
        return { success: false, message: 'Cannot reach server. Is the backend running?' };
    }
}

async function apiRegister(userData) {
    try {
        const { ok, data } = await apiPost('/auth/register', userData);
        if (ok) {
            return { success: true };
        }
        return { success: false, message: data.error || 'Registration failed' };
    } catch {
        return { success: false, message: 'Cannot reach server. Is the backend running?' };
    }
}

async function apiLogout() {
    const token = getToken();
    if (token) {
        try {
            await fetch(`${BACKEND_URL}/auth/logout`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${token}` },
            });
        } catch { /* best-effort */ }
    }
    clearSession();
}

// ---------------------------------------------------------------------------
//  UI helpers
// ---------------------------------------------------------------------------
function showLoading(btn, text) {
    btn.disabled = true;
    btn._originalText = btn.textContent;
    btn.textContent = text || 'Please wait...';
}

function stopLoading(btn) {
    btn.disabled = false;
    btn.textContent = btn._originalText || btn.textContent;
}

function showError(divId, message) {
    const el = document.getElementById(divId);
    if (el) { el.textContent = message; el.style.display = 'block'; }
}

function hideError(divId) {
    const el = document.getElementById(divId);
    if (el) el.style.display = 'none';
}

// ---------------------------------------------------------------------------
//  Form handlers
// ---------------------------------------------------------------------------
async function handleLogin(event) {
    event.preventDefault();

    const email    = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    const btn      = event.target.querySelector('button[type="submit"]');

    hideError('loginError');
    showLoading(btn, 'Logging in...');

    const result = await apiLogin(email, password);

    stopLoading(btn);

    if (result.success) {
        showDashboard();
        setupAuthListeners();
        attachLogoutListener();
    } else {
        showError('loginError', result.message);
    }
}

async function handleRegister(event) {
    event.preventDefault();

    const password        = document.getElementById('regPassword').value;
    const confirmPassword = document.getElementById('regPasswordConfirm').value;
    const btn             = event.target.querySelector('button[type="submit"]');

    hideError('registerError');

    if (password !== confirmPassword) {
        return showError('registerError', 'Passwords do not match');
    }
    if (password.length < 6) {
        return showError('registerError', 'Password must be at least 6 characters');
    }

    const userData = {
        name:     document.getElementById('regName').value.trim(),
        email:    document.getElementById('regEmail').value.trim(),
        phone:    document.getElementById('regPhone').value.trim(),
        address:  document.getElementById('regAddress').value.trim(),
        password,
    };

    showLoading(btn, 'Registering...');
    const result = await apiRegister(userData);
    stopLoading(btn);

    if (result.success) {
        document.getElementById('registerForm').reset();

        // Switch to login tab
        document.querySelectorAll('.auth-tab-btn').forEach(function(b) { b.classList.remove('active'); });
        document.querySelector('[data-tab="login"]').classList.add('active');
        document.querySelectorAll('.auth-tab-content').forEach(function(t) {
            t.style.display = 'none';
            t.classList.remove('active');
        });
        var loginTab = document.getElementById('loginTab');
        if (loginTab) { loginTab.style.display = 'block'; loginTab.classList.add('active'); }

        // Success banner
        var msg = document.createElement('div');
        msg.style.cssText = 'background:#dcfce7;border:1px solid #86efac;color:#15803d;padding:10px 12px;border-radius:6px;font-size:12px;margin-bottom:15px;';
        msg.textContent = 'Registration successful! Please log in with your credentials.';
        var loginForm = document.getElementById('loginForm');
        if (loginForm && loginForm.parentElement) {
            loginForm.parentElement.insertBefore(msg, loginForm);
        }
        setTimeout(function() { if (msg.parentElement) msg.remove(); }, 4000);
    } else {
        showError('registerError', result.message);
    }
}

// ---------------------------------------------------------------------------
//  Dashboard display
// ---------------------------------------------------------------------------
function showAuthModal() {
    document.getElementById('authContainer').style.display = 'flex';
    document.getElementById('dashboardContainer').style.display = 'none';
}

function showDashboard() {
    var user = getCurrentUser();
    populateProfileCard(user);
    document.getElementById('authContainer').style.display = 'none';
    document.getElementById('dashboardContainer').style.display = 'block';
    setupProfileMenu();
    attachLogoutListener();
}

function populateProfileCard(user) {
    if (!user) return;

    var welcomeEl = document.getElementById('userName');
    if (welcomeEl) {
        welcomeEl.textContent = 'Welcome, ' + (user.name || 'User');
    }

    var fields = [
        { id: 'profileName', value: user.name || '' },
        { id: 'profileEmail', value: user.email || '' },
        { id: 'profilePhone', value: user.phone || '' },
        { id: 'profileAddress', value: user.address || '' }
    ];

    fields.forEach(function(field) {
        var el = document.getElementById(field.id);
        if (el) {
            el.textContent = field.value;
        }
    });
}

function setupProfileMenu() {
    if (profileMenuInitialized) return;

    var trigger = document.getElementById('profileTrigger');
    var dropdown = document.getElementById('profileDropdown');

    if (!trigger || !dropdown) return;

    trigger.addEventListener('click', function(event) {
        event.stopPropagation();
        dropdown.classList.toggle('show');
    });

    dropdown.addEventListener('click', function(event) {
        event.stopPropagation();
    });

    document.addEventListener('click', function() {
        dropdown.classList.remove('show');
    });

    profileMenuInitialized = true;
}

function attachLogoutListener() {
    var btn = document.getElementById('logoutBtn');
    if (btn) {
        btn.onclick = async function(e) {
            e.preventDefault();
            await apiLogout();
            location.reload();
        };
    }
}

function setupAuthListeners() {
    document.querySelectorAll('.auth-tab-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();

            var tabName = this.getAttribute('data-tab');
            document.querySelectorAll('.auth-tab-btn').forEach(function(b) { b.classList.remove('active'); });
            this.classList.add('active');
            document.querySelectorAll('.auth-tab-content').forEach(function(t) {
                t.style.display = 'none';
                t.classList.remove('active');
            });
            var tab = document.getElementById(tabName + 'Tab');
            if (tab) { tab.style.display = 'block'; tab.classList.add('active'); }
        });
    });

    attachLogoutListener();
}

// ---------------------------------------------------------------------------
//  Initialise on DOM ready
// ---------------------------------------------------------------------------
function initAuth() {
    if (isAuthenticated()) {
        showDashboard();
    } else {
        showAuthModal();
        setupAuthListeners();
    }
}

window.handleLogin    = handleLogin;
window.handleRegister = handleRegister;

document.addEventListener('DOMContentLoaded', initAuth);
