function renderDomestic() {
    const content = document.getElementById('domestic');
    if (!content) return;
    
    content.innerHTML = `
        <div class="card domestic">
            <div class="card-header flex-between">
                <div>
                    <div class="card-title">Domestic Waste Quality Monitor</div>
                    <div class="card-description">Real-time BOD, COD, and TOC measurements by district and taluka</div>
                </div>
                <div class="select-group" style="display: flex; gap: 10px; width: auto;">
                    <select id="districtSelect" class="select-trigger">
                        <option value="">Select District</option>
                        ${Object.keys(maharashtraData).map(district => 
                            `<option value="${district}">${district}</option>`
                        ).join('')}
                    </select>
                    <select id="talukaSelect" class="select-trigger">
                        <option value="">Select Taluka</option>
                    </select>
                </div>
            </div>
            <div class="card-content">
                <div class="metrics-grid">
                    <div class="metric-card">
                        <div class="metric-label">BOD (mg/L)</div>
                        <div class="metric-value" id="bodValue">120</div>
                        <div class="metric-description">Biochemical Oxygen Demand</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-label">COD (mg/L)</div>
                        <div class="metric-value" id="codValue">250</div>
                        <div class="metric-description">Chemical Oxygen Demand</div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-label">TOC (mg/L)</div>
                        <div class="metric-value" id="tocValue">85</div>
                        <div class="metric-description">Total Organic Carbon</div>
                    </div>
                </div>

                <div class="chart-container">
                    <div class="chart-title">Water Quality Trend</div>
                    <div style="position: relative; height: 300px;">
                        <canvas id="trendChart"></canvas>
                    </div>
                </div>

                <div class="chart-container" style="margin-top: 20px;">
                    <div class="chart-title">Taluka Comparison - Current BOD Levels</div>
                    <div style="position: relative; height: 250px;">
                        <canvas id="comparisonChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    `;

    setTimeout(() => {
        initDomesticListeners();
        initDomesticCharts();
    }, 100);
}

function initDomesticListeners() {
    const districtSelect = document.getElementById('districtSelect');
    const talukaSelect = document.getElementById('talukaSelect');
    
    if (!districtSelect || !talukaSelect) return;
    
    districtSelect.addEventListener('change', function() {
        const district = this.value;
        talukaSelect.innerHTML = '<option value="">Select Taluka</option>';
        
        if (district && maharashtraData[district]) {
            maharashtraData[district].talukas.forEach(taluka => {
                const option = document.createElement('option');
                option.value = `${district}-${taluka}`;
                option.textContent = taluka;
                talukaSelect.appendChild(option);
            });
            talukaSelect.disabled = false;
            initDomesticCharts();
        } else {
            talukaSelect.disabled = true;
        }
    });
    
    talukaSelect.addEventListener('change', function() {
        const location = this.value;
        if (location) {
            updateDomesticData(location);
            initDomesticCharts();
        }
    });
}

function updateDomesticData(location) {
    const [district, taluka] = location.split('-');
    const data = waterQualityData[location] || {
        BOD: Math.floor(Math.random() * 150) + 50,
        COD: Math.floor(Math.random() * 300) + 150,
        TOC: Math.floor(Math.random() * 100) + 50,
        timeline: [
            { date: '2024-01-01', BOD: 100, COD: 220, TOC: 70 },
            { date: '2024-01-02', BOD: 110, COD: 235, TOC: 75 },
            { date: '2024-01-03', BOD: 115, COD: 240, TOC: 80 },
            { date: '2024-01-04', BOD: 120, COD: 250, TOC: 85 }
        ]
    };
    
    document.getElementById('bodValue').textContent = data.BOD;
    document.getElementById('codValue').textContent = data.COD;
    document.getElementById('tocValue').textContent = data.TOC;
    document.querySelector('.chart-title').textContent = `Water Quality Trend - ${taluka}, ${district}`;
    updateTrendChart(data.timeline);
}

function initDomesticCharts() {
    const district = document.getElementById('districtSelect')?.value;
    const talukaValue = document.getElementById('talukaSelect')?.value;
    
    if (!district) {
        return;
    }

    const talukas = maharashtraData[district]?.talukas || [];
    
    const talukaComparisonData = talukas.map(taluka => {
        const bod = Math.floor(Math.random() * 150) + 50;
        return {
            taluka: taluka,
            BOD: bod
        };
    });

    if (chartInstances.trendChart) chartInstances.trendChart.destroy();
    if (chartInstances.comparisonChart) chartInstances.comparisonChart.destroy();

    const location = talukaValue || (district + '-' + talukas[0]);
    const [currentDistrict, currentTaluka] = location.split('-');
    const data = waterQualityData[location] || {
        BOD: Math.floor(Math.random() * 150) + 50,
        COD: Math.floor(Math.random() * 300) + 150,
        TOC: Math.floor(Math.random() * 100) + 50,
        timeline: [
            { date: '2024-01-01', BOD: 100, COD: 220, TOC: 70 },
            { date: '2024-01-02', BOD: 110, COD: 235, TOC: 75 },
            { date: '2024-01-03', BOD: 115, COD: 240, TOC: 80 },
            { date: '2024-01-04', BOD: 120, COD: 250, TOC: 85 }
        ]
    };

    const lineDatasets = [
        {
            label: 'BOD',
            data: data.timeline.map(d => d.BOD),
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            tension: 0.4,
            borderWidth: 2,
            fill: true
        },
        {
            label: 'COD',
            data: data.timeline.map(d => d.COD),
            borderColor: '#06b6d4',
            backgroundColor: 'rgba(6, 182, 212, 0.1)',
            tension: 0.4,
            borderWidth: 2,
            fill: true
        },
        {
            label: 'TOC',
            data: data.timeline.map(d => d.TOC),
            borderColor: '#14b8a6',
            backgroundColor: 'rgba(20, 184, 166, 0.1)',
            tension: 0.4,
            borderWidth: 2,
            fill: false
        }
    ];

    createLineChart('trendChart', data.timeline, lineDatasets);

    const canvasComparison = document.getElementById('comparisonChart');
    if (canvasComparison && canvasComparison.getContext) {
        const ctx = canvasComparison.getContext('2d');
        chartInstances.comparisonChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: talukaComparisonData.map(d => d.taluka),
                datasets: [{
                    label: 'BOD (mg/L)',
                    data: talukaComparisonData.map(d => d.BOD),
                    backgroundColor: '#3b82f6',
                    borderRadius: 8,
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'top' } },
                scales: { y: { beginAtZero: true, max: 200 } }
            }
        });
    }
}

function updateTrendChart(timeline) {
    if (chartInstances.trendChart) {
        chartInstances.trendChart.data.labels = timeline.map(d => d.date);
        chartInstances.trendChart.data.datasets[0].data = timeline.map(d => d.BOD);
        chartInstances.trendChart.data.datasets[1].data = timeline.map(d => d.COD);
        chartInstances.trendChart.data.datasets[2].data = timeline.map(d => d.TOC);
        chartInstances.trendChart.update();
    }
}
