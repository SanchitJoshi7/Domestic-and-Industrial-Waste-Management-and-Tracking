function renderIndustrial() {
    const content = document.getElementById('industrial');
    content.innerHTML = `
        <div class="card industrial">
            <div class="card-header flex-between">
                <div>
                    <div class="card-title">Industrial Waste Management</div>
                    <div class="card-description">Monitoring solid, liquid, and air emissions by district and taluka</div>
                </div>
                <div class="select-group" style="display: flex; gap: 10px; width: auto;">
                    <select id="indDistrictSelect" class="select-trigger">
                        <option value="">Select District</option>
                        ${Object.keys(maharashtraData).map(district => 
                            `<option value="${district}">${district}</option>`
                        ).join('')}
                    </select>
                    <select id="indTalukaSelect" class="select-trigger">
                        <option value="">Select Taluka</option>
                    </select>
                </div>
            </div>
            <div class="card-content">
                <div class="tab-list" style="margin-bottom: 20px;">
                    <button class="tab-trigger active industrial-subtab" data-subtab="solid">📦 Solid Waste</button>
                    <button class="tab-trigger industrial-subtab" data-subtab="liquid">💧 Liquid Waste</button>
                    <button class="tab-trigger industrial-subtab" data-subtab="air">💨 Air Emissions</button>
                </div>

                <div id="solid-industrial" class="subtab-content" style="display: block;">
                    ${renderWasteSection('Solid Waste', solidWasteData, 'MT', '#f59e0b', 4610, 2, 68)}
                </div>

                <div id="liquid-industrial" class="subtab-content" style="display: none;">
                    ${renderWasteSection('Liquid Waste', liquidWasteData, 'M³', '#3b82f6', 19800, 5, 72)}
                </div>

                <div id="air-industrial" class="subtab-content" style="display: none;">
                    ${renderWasteSection('Air Emissions', airWasteData, 'MT CO₂', '#6b7280', 10000, 8, 15)}
                </div>
            </div>
        </div>
    `;

    setTimeout(() => {
        initIndustrialListeners();
        initIndustrialCharts('solid');
    }, 100);
}

function renderWasteSection(title, data, unit, color, total, risks, rate) {
    const metrics = title === 'Solid Waste' ? [
        { label: 'Total Solid Waste', value: total, unit: 'Metric Tons/Month', color: 'amber' },
        { label: 'High Risk Industries', value: risks, unit: 'Requiring intervention', color: 'red' },
        { label: 'Compliance Rate', value: rate + '%', unit: 'Industries compliant', color: 'green' }
    ] : title === 'Liquid Waste' ? [
        { label: 'Total Liquid Waste', value: total, unit: 'Cubic Meters/Month', color: 'blue' },
        { label: 'Critical Pollutants', value: risks, unit: 'Detected substances', color: 'red' },
        { label: 'Treatment Rate', value: rate + '%', unit: 'Treated before discharge', color: 'yellow' }
    ] : [
        { label: 'Total Air Emissions', value: total, unit: 'Metric Tons CO₂ Eq./Month', color: 'gray' },
        { label: 'Hazardous Emissions', value: risks, unit: 'Sources detected', color: 'red' },
        { label: 'Reduction Target', value: rate + '%', unit: 'Year-on-year goal', color: 'green' }
    ];

    return `
        <div class="metrics-grid">
            ${metrics.map(m => `
                <div class="metric-card" style="background: linear-gradient(to bottom right, #fe${m.color}00, #fe${m.color}50); border: 1px solid #fc${m.color}00;">
                    <div class="metric-label">${m.label}</div>
                    <div class="metric-value">${m.value}</div>
                    <div class="metric-description">${m.unit}</div>
                </div>
            `).join('')}
        </div>

        <div class="chart-container">
            <div class="chart-title">${title} - Industry Breakdown</div>
            <div style="position: relative; height: 250px;">
                <canvas id="${title.toLowerCase().replace(/\s+/g, '')}PieChart"></canvas>
            </div>
        </div>

        <div class="chart-container">
            <div class="chart-title">${title} - Tonnage Distribution</div>
            <div style="position: relative; height: 250px;">
                <canvas id="${title.toLowerCase().replace(/\s+/g, '')}BarChart"></canvas>
            </div>
        </div>

        <div class="chart-container">
            <div class="chart-title">Detailed Breakdown</div>
            <div class="table-wrapper">
                <table id="${title.toLowerCase().replace(/\s+/g, '')}Table">
                    <thead>
                        <tr>
                            <th>Industry</th>
                            <th style="text-align: right;">Percentage</th>
                            <th style="text-align: right;">Tonnage (${unit})</th>
                            <th style="text-align: right;">Status</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    `;
}

function initIndustrialListeners() {
    const indDistrictSelect = document.getElementById('indDistrictSelect');
    const indTalukaSelect = document.getElementById('indTalukaSelect');
    
    if (indDistrictSelect) {
        indDistrictSelect.addEventListener('change', function() {
            const district = this.value;
            indTalukaSelect.innerHTML = '<option value="">Select Taluka</option>';
            
            if (district && maharashtraData[district]) {
                maharashtraData[district].talukas.forEach(taluka => {
                    const option = document.createElement('option');
                    option.value = `${district}-${taluka}`;
                    option.textContent = taluka;
                    indTalukaSelect.appendChild(option);
                });
                indTalukaSelect.disabled = false;
            } else {
                indTalukaSelect.disabled = true;
            }
        });
    }
    
    document.querySelectorAll('.industrial-subtab').forEach(btn => {
        btn.addEventListener('click', function() {
            const subtab = this.getAttribute('data-subtab');
            document.querySelectorAll('.subtab-content').forEach(t => t.style.display = 'none');
            document.getElementById(`${subtab}-industrial`).style.display = 'block';
            document.querySelectorAll('.industrial-subtab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            setTimeout(() => initIndustrialCharts(subtab), 50);
        });
    });
}

function initIndustrialCharts(type) {
    setTimeout(() => {
        let data, chartId, color;

        if (type === 'solid') {
            data = solidWasteData;
            chartId = 'solidwaste';
            color = '#f59e0b';
        } else if (type === 'liquid') {
            data = liquidWasteData;
            chartId = 'liquidwaste';
            color = '#3b82f6';
        } else {
            data = airWasteData;
            chartId = 'airemissions';
            color = '#6b7280';
        }

        createPieChart(`${chartId}PieChart`, data, color);
        createBarChart(`${chartId}BarChart`, data, color);
        populateTable(`${chartId}Table`, data);
    }, 100);
}