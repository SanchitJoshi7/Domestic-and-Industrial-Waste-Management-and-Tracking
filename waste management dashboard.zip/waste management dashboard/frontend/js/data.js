let waterQualityData = {};
let allWaterQualityData = [];
let solidWasteData = [];
let liquidWasteData = [];
let airWasteData = [];
let pollutionZones = [];
let authorities = [];

// API Configuration - Update these based on your backend ports
const API_URLS = {
    domestic: 'http://localhost:5000/api',
    industrial: 'http://localhost:5000/api',
    pollution: 'http://localhost:5000/api',
    alerts: 'http://localhost:5000/api'
};

async function loadDomesticData() {
    try {
        console.log('Loading domestic data...');
        
        // Mock data - Replace with actual API calls
        waterQualityData['North Zone'] = {
            zone: 'North Zone',
            BOD: 120,
            COD: 250,
            TOC: 85,
            date: new Date().toISOString().split('T')[0],
            timeline: [
                { date: '2024-01-01', BOD: 100, COD: 220, TOC: 70 },
                { date: '2024-01-02', BOD: 110, COD: 235, TOC: 75 },
                { date: '2024-01-03', BOD: 115, COD: 240, TOC: 80 },
                { date: '2024-01-04', BOD: 120, COD: 250, TOC: 85 }
            ]
        };
        
        waterQualityData['South Zone'] = {
            zone: 'South Zone',
            BOD: 95,
            COD: 200,
            TOC: 65,
            date: new Date().toISOString().split('T')[0],
            timeline: [
                { date: '2024-01-01', BOD: 80, COD: 180, TOC: 55 },
                { date: '2024-01-02', BOD: 85, COD: 190, TOC: 60 },
                { date: '2024-01-03', BOD: 90, COD: 195, TOC: 63 },
                { date: '2024-01-04', BOD: 95, COD: 200, TOC: 65 }
            ]
        };
        
        waterQualityData['East Zone'] = {
            zone: 'East Zone',
            BOD: 140,
            COD: 280,
            TOC: 95,
            date: new Date().toISOString().split('T')[0],
            timeline: [
                { date: '2024-01-01', BOD: 120, COD: 260, TOC: 80 },
                { date: '2024-01-02', BOD: 130, COD: 270, TOC: 88 },
                { date: '2024-01-03', BOD: 135, COD: 275, TOC: 92 },
                { date: '2024-01-04', BOD: 140, COD: 280, TOC: 95 }
            ]
        };
        
        waterQualityData['West Zone'] = {
            zone: 'West Zone',
            BOD: 110,
            COD: 230,
            TOC: 75,
            date: new Date().toISOString().split('T')[0],
            timeline: [
                { date: '2024-01-01', BOD: 95, COD: 210, TOC: 65 },
                { date: '2024-01-02', BOD: 100, COD: 220, TOC: 70 },
                { date: '2024-01-03', BOD: 105, COD: 225, TOC: 72 },
                { date: '2024-01-04', BOD: 110, COD: 230, TOC: 75 }
            ]
        };
        
        waterQualityData['Central Zone'] = {
            zone: 'Central Zone',
            BOD: 130,
            COD: 260,
            TOC: 88,
            date: new Date().toISOString().split('T')[0],
            timeline: [
                { date: '2024-01-01', BOD: 110, COD: 240, TOC: 75 },
                { date: '2024-01-02', BOD: 120, COD: 250, TOC: 80 },
                { date: '2024-01-03', BOD: 125, COD: 255, TOC: 85 },
                { date: '2024-01-04', BOD: 130, COD: 260, TOC: 88 }
            ]
        };
        
        allWaterQualityData = [
            { area: 'North Zone', BOD: 120, COD: 250, TOC: 85 },
            { area: 'South Zone', BOD: 95, COD: 200, TOC: 65 },
            { area: 'East Zone', BOD: 140, COD: 280, TOC: 95 },
            { area: 'West Zone', BOD: 110, COD: 230, TOC: 75 },
            { area: 'Central Zone', BOD: 130, COD: 260, TOC: 88 }
        ];
        
        console.log('Domestic data loaded successfully');
        return true;
    } catch (error) {
        console.error('Error loading domestic data:', error);
        return false;
    }
}

async function loadIndustrialData() {
    try {
        console.log('Loading industrial data...');
        
        solidWasteData = [
            { name: 'Construction', percentage: 35, tons: 1500 },
            { name: 'Mining', percentage: 25, tons: 1200 },
            { name: 'Manufacturing', percentage: 20, tons: 950 },
            { name: 'Food Processing', percentage: 12, tons: 580 },
            { name: 'Others', percentage: 8, tons: 380 }
        ];
        
        liquidWasteData = [
            { name: 'Chemical Plants', percentage: 40, tons: 8000 },
            { name: 'Textile Mills', percentage: 28, tons: 5600 },
            { name: 'Paper Mills', percentage: 18, tons: 3600 },
            { name: 'Food Industries', percentage: 10, tons: 2000 },
            { name: 'Others', percentage: 4, tons: 800 }
        ];
        
        airWasteData = [
            { name: 'Power Plants', percentage: 45, tons: 4500 },
            { name: 'Steel Industry', percentage: 30, tons: 3000 },
            { name: 'Cement Plants', percentage: 18, tons: 1800 },
            { name: 'Chemical Plants', percentage: 5, tons: 500 },
            { name: 'Others', percentage: 2, tons: 200 }
        ];
        
        console.log('Industrial data loaded successfully');
        console.log('Solid Waste:', solidWasteData);
        console.log('Liquid Waste:', liquidWasteData);
        console.log('Air Waste:', airWasteData);
        return true;
    } catch (error) {
        console.error('Error loading industrial data:', error);
        return false;
    }
}

async function loadPollutionData() {
    try {
        console.log('Loading pollution data...');
        
        pollutionZones = [
            {
                id: 'zone_1',
                name: 'North District',
                level: 85,
                latitude: 21.1458,
                longitude: 79.0882,
                zone_type: 'Industrial',
                PM25: 95,
                PM10: 180,
                NO2: 120,
                SO2: 85
            },
            {
                id: 'zone_2',
                name: 'South District',
                level: 65,
                latitude: 21.0995,
                longitude: 79.0760,
                zone_type: 'Mixed',
                PM25: 72,
                PM10: 140,
                NO2: 95,
                SO2: 65
            },
            {
                id: 'zone_3',
                name: 'East District',
                level: 110,
                latitude: 21.1150,
                longitude: 79.1200,
                zone_type: 'Industrial',
                PM25: 130,
                PM10: 220,
                NO2: 150,
                SO2: 110
            },
            {
                id: 'zone_4',
                name: 'West District',
                level: 75,
                latitude: 21.1300,
                longitude: 79.0600,
                zone_type: 'Residential',
                PM25: 85,
                PM10: 160,
                NO2: 110,
                SO2: 75
            }
        ];
        
        console.log('Pollution data loaded successfully');
        return true;
    } catch (error) {
        console.error('Error loading pollution data:', error);
        return false;
    }
}

async function loadAuthorities() {
    try {
        authorities = [
            {
                id: 'municipality',
                name: 'Municipality',
                icon: '🏛️',
                color: 'blue',
                email: 'alerts@municipality.gov.in',
                description: 'Local municipal corporation',
                templates: [
                    'Overflowing garbage bin not collected for 3+ days',
                    'Illegal dumping of waste in residential area',
                    'Blocked drainage causing sanitation issues',
                    'Stray animals near open waste dump'
                ]
            },
            {
                id: 'spcb',
                name: 'State Pollution Control Board',
                icon: '🌍',
                color: 'green',
                email: 'grievances@spcb.gov.in',
                description: 'State pollution authority',
                templates: [
                    'Factory releasing untreated effluents into water body',
                    'Air pollution from industrial chimney exceeding limits',
                    'Chemical waste illegally dumped near residential area',
                    'Noise pollution from industrial unit beyond permitted hours'
                ]
            },
            {
                id: 'cpcb',
                name: 'Central Pollution Control Board',
                icon: '🏢',
                color: 'purple',
                email: 'complaints@cpcb.gov.in',
                description: 'National environment authority',
                templates: [
                    'Hazardous waste disposal violating national norms',
                    'Cross-border pollution affecting multiple states',
                    'Large-scale environmental damage requiring central intervention',
                    'Non-compliance with national environmental standards'
                ]
            }
        ];
        return true;
    } catch (error) {
        console.error('Error loading authorities:', error);
        return false;
    }
}

// Load all data on startup
Promise.all([
    loadDomesticData(),
    loadIndustrialData(),
    loadPollutionData(),
    loadAuthorities()
]).then(() => {
    console.log('All data loaded');
}).catch(error => {
    console.error('Error loading data:', error);
});
