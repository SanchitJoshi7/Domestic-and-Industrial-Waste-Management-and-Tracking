-- Main Database Initialization Script
-- Execute this file to set up the complete database schema

-- Drop existing tables if they exist (for fresh setup)
-- Comment these out if you want to preserve existing data
DROP TABLE IF EXISTS audit_logs CASCADE;
DROP TABLE IF EXISTS alerts CASCADE;
DROP TABLE IF EXISTS sensor_data CASCADE;
DROP TABLE IF EXISTS authorities CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- Drop sequences
DROP SEQUENCE IF EXISTS alert_number_seq;

-- Drop existing functions and triggers
DROP FUNCTION IF EXISTS update_users_updated_at() CASCADE;
DROP FUNCTION IF EXISTS update_sensor_data_updated_at() CASCADE;
DROP FUNCTION IF EXISTS update_alerts_updated_at() CASCADE;
DROP FUNCTION IF EXISTS update_authorities_updated_at() CASCADE;
DROP FUNCTION IF EXISTS generate_alert_number() CASCADE;
DROP FUNCTION IF EXISTS set_alert_acknowledged() CASCADE;
DROP FUNCTION IF EXISTS audit_log_trigger() CASCADE;
DROP FUNCTION IF EXISTS create_sensor_data_partition() CASCADE;

-- Execute schema files
\i schemas/users.sql
\i schemas/authorities.sql
\i schemas/sensor_data.sql
\i schemas/alerts.sql
\i schemas/audit_logs.sql

-- Execute seed files
\i seeds/authorities_seed.sql
\i seeds/initial_data.sql

-- Create views for easier querying

-- View: Recent Alerts
CREATE OR REPLACE VIEW recent_alerts AS
SELECT 
    a.id,
    a.alert_number,
    a.user_id,
    u.name as user_name,
    u.email as user_email,
    a.authority_id,
    auth.name as authority_name,
    a.message,
    a.address,
    a.status,
    a.priority,
    a.created_at,
    a.updated_at
FROM alerts a
JOIN users u ON a.user_id = u.id
JOIN authorities auth ON a.authority_id = auth.id
WHERE a.created_at > CURRENT_DATE - INTERVAL '30 days'
ORDER BY a.created_at DESC;

-- View: Pollution Statistics
CREATE OR REPLACE VIEW pollution_statistics AS
SELECT 
    zone_id,
    zone_name,
    ROUND(AVG(aqi_level)::NUMERIC, 2) as avg_aqi,
    MAX(aqi_level) as max_aqi,
    MIN(aqi_level) as min_aqi,
    ROUND(AVG(pm25)::NUMERIC, 2) as avg_pm25,
    ROUND(AVG(pm10)::NUMERIC, 2) as avg_pm10,
    COUNT(*) as total_readings,
    MAX(timestamp) as last_reading
FROM sensor_data
WHERE sensor_type = 'pollution_zone'
    AND timestamp > CURRENT_TIMESTAMP - INTERVAL '7 days'
GROUP BY zone_id, zone_name
ORDER BY avg_aqi DESC;

-- View: Authority Performance
CREATE OR REPLACE VIEW authority_performance AS
SELECT 
    a.id,
    a.name as authority_name,
    COUNT(*) as total_alerts,
    COUNT(CASE WHEN a.status = 'submitted' THEN 1 END) as pending_alerts,
    COUNT(CASE WHEN a.status = 'resolved' THEN 1 END) as resolved_alerts,
    ROUND(
        (COUNT(CASE WHEN a.status = 'resolved' THEN 1 END)::NUMERIC / 
         COUNT(*)::NUMERIC * 100),
        2
    ) as resolution_rate,
    ROUND(
        AVG(EXTRACT(EPOCH FROM (COALESCE(a.resolved_at, CURRENT_TIMESTAMP) - a.created_at))/3600)::NUMERIC,
        2
    ) as avg_resolution_hours
FROM alerts a
JOIN authorities auth ON a.authority_id = auth.id
WHERE a.created_at > CURRENT_TIMESTAMP - INTERVAL '30 days'
GROUP BY a.id, a.name
ORDER BY total_alerts DESC;

-- View: Water Quality by Zone
CREATE OR REPLACE VIEW water_quality_by_zone AS
SELECT 
    zone,
    ROUND(AVG(bod)::NUMERIC, 2) as avg_bod,
    ROUND(AVG(cod)::NUMERIC, 2) as avg_cod,
    ROUND(AVG(toc)::NUMERIC, 2) as avg_toc,
    MAX(bod) as max_bod,
    MAX(cod) as max_cod,
    MAX(toc) as max_toc,
    COUNT(*) as reading_count,
    MAX(timestamp) as latest_reading
FROM sensor_data
WHERE sensor_type = 'domestic_waste'
    AND timestamp > CURRENT_TIMESTAMP - INTERVAL '30 days'
GROUP BY zone
ORDER BY avg_bod DESC;

-- View: Industrial Waste Summary
CREATE OR REPLACE VIEW industrial_waste_summary AS
SELECT 
    sensor_type,
    industry_name,
    ROUND(AVG(percentage)::NUMERIC, 2) as avg_percentage,
    ROUND(AVG(tons)::NUMERIC, 2) as avg_tons,
    SUM(tons) as total_tons,
    COUNT(*) as reading_count,
    MAX(timestamp) as latest_reading
FROM sensor_data
WHERE sensor_type IN ('industrial_solid', 'industrial_liquid', 'industrial_air')
    AND timestamp > CURRENT_TIMESTAMP - INTERVAL '30 days'
GROUP BY sensor_type, industry_name
ORDER BY total_tons DESC;

-- Print initialization summary
\echo '========================================'
\echo 'Database Initialization Complete'
\echo '========================================'
\echo 'Tables Created:'
\echo '  - users'
\echo '  - authorities'
\echo '  - sensor_data'
\echo '  - alerts'
\echo '  - audit_logs'
\echo ''
\echo 'Views Created:'
\echo '  - recent_alerts'
\echo '  - pollution_statistics'
\echo '  - authority_performance'
\echo '  - water_quality_by_zone'
\echo '  - industrial_waste_summary'
\echo ''
\echo 'Seed Data Loaded:'
\echo '  - 5 authorities'
\echo '  - 4 test users'
\echo '  - Sample sensor readings'
\echo '========================================'
