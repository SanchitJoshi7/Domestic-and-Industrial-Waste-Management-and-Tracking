-- Maharashtra Districts & Talukas Test Data - Domestic Waste
INSERT INTO sensor_data (sensor_type, district, taluka, bod, cod, toc, timestamp) VALUES 
('domestic_waste', 'Pune', 'Pune', 120, 250, 85, CURRENT_TIMESTAMP),
('domestic_waste', 'Pune', 'Ambegaon', 105, 220, 75, CURRENT_TIMESTAMP),
('domestic_waste', 'Pune', 'Baramati', 115, 240, 80, CURRENT_TIMESTAMP),
('domestic_waste', 'Mumbai', 'Mumbai', 95, 200, 65, CURRENT_TIMESTAMP),
('domestic_waste', 'Mumbai', 'Ambernath', 88, 180, 60, CURRENT_TIMESTAMP),
('domestic_waste', 'Nagpur', 'Nagpur', 110, 230, 78, CURRENT_TIMESTAMP),
('domestic_waste', 'Nagpur', 'Bhandara', 100, 210, 70, CURRENT_TIMESTAMP),
('domestic_waste', 'Aurangabad', 'Aurangabad', 125, 260, 88, CURRENT_TIMESTAMP),
('domestic_waste', 'Aurangabad', 'Kannad', 108, 225, 76, CURRENT_TIMESTAMP),
('domestic_waste', 'Nashik', 'Nashik', 112, 235, 80, CURRENT_TIMESTAMP),
('domestic_waste', 'Nashik', 'Malegaon', 118, 245, 83, CURRENT_TIMESTAMP),
('domestic_waste', 'Satara', 'Satara', 105, 220, 74, CURRENT_TIMESTAMP),
('domestic_waste', 'Satara', 'Phaltan', 98, 205, 68, CURRENT_TIMESTAMP),
('domestic_waste', 'Solapur', 'Solapur', 115, 240, 82, CURRENT_TIMESTAMP),
('domestic_waste', 'Solapur', 'Pandharpur', 110, 230, 78, CURRENT_TIMESTAMP),
('domestic_waste', 'Kolhapur', 'Kolhapur', 120, 250, 85, CURRENT_TIMESTAMP),
('domestic_waste', 'Kolhapur', 'Ichalkaranji', 112, 235, 80, CURRENT_TIMESTAMP),
('domestic_waste', 'Sangli', 'Sangli', 108, 225, 76, CURRENT_TIMESTAMP),
('domestic_waste', 'Sangli', 'Miraj', 103, 215, 72, CURRENT_TIMESTAMP),
('domestic_waste', 'Ratnagiri', 'Ratnagiri', 102, 213, 71, CURRENT_TIMESTAMP),
('domestic_waste', 'Ratnagiri', 'Chiplun', 98, 205, 68, CURRENT_TIMESTAMP),
('domestic_waste', 'Sindhudurg', 'Sindhudurg', 100, 210, 70, CURRENT_TIMESTAMP),
('domestic_waste', 'Thane', 'Thane', 118, 245, 83, CURRENT_TIMESTAMP),
('domestic_waste', 'Thane', 'Virar', 110, 230, 78, CURRENT_TIMESTAMP),
('domestic_waste', 'Raigarh', 'Panvel', 105, 220, 75, CURRENT_TIMESTAMP),
('domestic_waste', 'Buldhana', 'Buldhana', 108, 225, 76, CURRENT_TIMESTAMP),
('domestic_waste', 'Akola', 'Akola', 112, 235, 80, CURRENT_TIMESTAMP),
('domestic_waste', 'Washim', 'Washim', 105, 220, 74, CURRENT_TIMESTAMP),
('domestic_waste', 'Amravati', 'Amravati', 110, 230, 78, CURRENT_TIMESTAMP),
('domestic_waste', 'Jalna', 'Jalna', 115, 240, 82, CURRENT_TIMESTAMP);

-- Maharashtra Districts & Talukas Test Data - Industrial Solid Waste
INSERT INTO sensor_data (sensor_type, district, taluka, industry_name, percentage, tons, timestamp) VALUES 
('industrial_solid', 'Pune', 'Pune', 'Construction', 35, 1500, CURRENT_TIMESTAMP),
('industrial_solid', 'Pune', 'Baramati', 'Mining', 25, 1200, CURRENT_TIMESTAMP),
('industrial_solid', 'Mumbai', 'Mumbai', 'Manufacturing', 20, 950, CURRENT_TIMESTAMP),
('industrial_solid', 'Nagpur', 'Nagpur', 'Food Processing', 12, 580, CURRENT_TIMESTAMP),
('industrial_solid', 'Aurangabad', 'Aurangabad', 'Construction', 30, 1400, CURRENT_TIMESTAMP),
('industrial_solid', 'Nashik', 'Nashik', 'Mining', 28, 1300, CURRENT_TIMESTAMP),
('industrial_solid', 'Satara', 'Satara', 'Manufacturing', 22, 1000, CURRENT_TIMESTAMP),
('industrial_solid', 'Solapur', 'Solapur', 'Food Processing', 15, 650, CURRENT_TIMESTAMP),
('industrial_solid', 'Kolhapur', 'Kolhapur', 'Construction', 32, 1450, CURRENT_TIMESTAMP),
('industrial_solid', 'Sangli', 'Sangli', 'Manufacturing', 18, 850, CURRENT_TIMESTAMP);

-- Maharashtra Districts & Talukas Test Data - Industrial Liquid Waste
INSERT INTO sensor_data (sensor_type, district, taluka, industry_name, percentage, tons, timestamp) VALUES 
('industrial_liquid', 'Pune', 'Pune', 'Chemical Plants', 40, 8000, CURRENT_TIMESTAMP),
('industrial_liquid', 'Pune', 'Baramati', 'Textile Mills', 28, 5600, CURRENT_TIMESTAMP),
('industrial_liquid', 'Mumbai', 'Mumbai', 'Paper Mills', 18, 3600, CURRENT_TIMESTAMP),
('industrial_liquid', 'Nagpur', 'Nagpur', 'Food Industries', 10, 2000, CURRENT_TIMESTAMP),
('industrial_liquid', 'Aurangabad', 'Aurangabad', 'Chemical Plants', 35, 7000, CURRENT_TIMESTAMP),
('industrial_liquid', 'Nashik', 'Nashik', 'Textile Mills', 32, 6400, CURRENT_TIMESTAMP),
('industrial_liquid', 'Satara', 'Satara', 'Paper Mills', 20, 4000, CURRENT_TIMESTAMP),
('industrial_liquid', 'Solapur', 'Solapur', 'Food Industries', 8, 1600, CURRENT_TIMESTAMP),
('industrial_liquid', 'Kolhapur', 'Kolhapur', 'Chemical Plants', 38, 7600, CURRENT_TIMESTAMP),
('industrial_liquid', 'Sangli', 'Sangli', 'Textile Mills', 25, 5000, CURRENT_TIMESTAMP);

-- Maharashtra Districts & Talukas Test Data - Industrial Air Emissions
INSERT INTO sensor_data (sensor_type, district, taluka, industry_name, percentage, tons, timestamp) VALUES 
('industrial_air', 'Pune', 'Pune', 'Power Plants', 45, 4500, CURRENT_TIMESTAMP),
('industrial_air', 'Pune', 'Baramati', 'Steel Industry', 30, 3000, CURRENT_TIMESTAMP),
('industrial_air', 'Mumbai', 'Mumbai', 'Cement Plants', 18, 1800, CURRENT_TIMESTAMP),
('industrial_air', 'Nagpur', 'Nagpur', 'Chemical Plants', 5, 500, CURRENT_TIMESTAMP),
('industrial_air', 'Aurangabad', 'Aurangabad', 'Power Plants', 48, 4800, CURRENT_TIMESTAMP),
('industrial_air', 'Nashik', 'Nashik', 'Steel Industry', 32, 3200, CURRENT_TIMESTAMP),
('industrial_air', 'Satara', 'Satara', 'Cement Plants', 20, 2000, CURRENT_TIMESTAMP),
('industrial_air', 'Solapur', 'Solapur', 'Power Plants', 42, 4200, CURRENT_TIMESTAMP),
('industrial_air', 'Kolhapur', 'Kolhapur', 'Steel Industry', 28, 2800, CURRENT_TIMESTAMP),
('industrial_air', 'Sangli', 'Sangli', 'Cement Plants', 15, 1500, CURRENT_TIMESTAMP);
