-- Initial Data Seed - Test Users and Sample Sensor Data

-- Insert test users
INSERT INTO users (
    username, 
    password_hash, 
    email, 
    phone, 
    name, 
    address, 
    is_admin, 
    is_active
) VALUES 
(
    'admin_user',
    '$2b$10$YIRfJSxvY1U.H9CfV8F0m.I9mDDlTGGvXH8A0L5JzXq5V5X.V5wFm',  -- password: admin123
    'admin@wastemanagement.com',
    '+91-9876543210',
    'System Administrator',
    'Admin Office, Pune',
    TRUE,
    TRUE
),
(
    'citizen_user1',
    '$2b$10$NKwYnM8hZx0A3J6L4K2P1.8L5M0N1O2P3Q4R5S6T7U8V9W0X1Y2Z3',  -- password: citizen123
    'citizen1@email.com',
    '+91-9123456789',
    'Rajesh Kumar',
    'Flat 101, ABC Building, Baner, Pune 411045',
    FALSE,
    TRUE
),
(
    'citizen_user2',
    '$2b$10$P0X1Y2Z3A4B5C6D7E8F9G0H1I2J3K4L5M6N7O8P9Q0R1S2T3U4V5W',  -- password: citizen456
    'citizen2@email.com',
    '+91-9876543211',
    'Priya Singh',
    'Flat 205, XYZ Apartments, Koregaon Park, Pune 411001',
    FALSE,
    TRUE
),
(
    'authority_officer1',
    '$2b$10$V5W0X1Y2Z3A4B5C6D7E8F9G0H1I2J3K4L5M6N7O8P9Q0R1S2T3U4',  -- password: officer123
    'officer@municipality.gov.in',
    '+91-020-2345-6700',
    'Municipal Officer',
    'Municipal Building, Pune',
    TRUE,
    TRUE
);

-- Insert sample sensor data - Domestic Waste
INSERT INTO sensor_data (
    sensor_type, 
    zone, 
    bod, 
    cod, 
    toc, 
    timestamp
) VALUES 
('domestic_waste', 'North Zone', 120, 250, 85, CURRENT_TIMESTAMP - INTERVAL '3 hours'),
('domestic_waste', 'North Zone', 125, 260, 88, CURRENT_TIMESTAMP - INTERVAL '2 hours'),
('domestic_waste', 'North Zone', 118, 245, 83, CURRENT_TIMESTAMP - INTERVAL '1 hour'),
('domestic_waste', 'North Zone', 130, 270, 92, CURRENT_TIMESTAMP),

('domestic_waste', 'South Zone', 95, 180, 62, CURRENT_TIMESTAMP - INTERVAL '3 hours'),
('domestic_waste', 'South Zone', 92, 175, 60, CURRENT_TIMESTAMP - INTERVAL '2 hours'),
('domestic_waste', 'South Zone', 98, 190, 65, CURRENT_TIMESTAMP - INTERVAL '1 hour'),
('domestic_waste', 'South Zone', 88, 170, 58, CURRENT_TIMESTAMP),

('domestic_waste', 'East Zone', 150, 310, 105, CURRENT_TIMESTAMP - INTERVAL '3 hours'),
('domestic_waste', 'East Zone', 155, 320, 110, CURRENT_TIMESTAMP - INTERVAL '2 hours'),
('domestic_waste', 'East Zone', 148, 305, 103, CURRENT_TIMESTAMP - INTERVAL '1 hour'),
('domestic_waste', 'East Zone', 160, 330, 115, CURRENT_TIMESTAMP),

('domestic_waste', 'West Zone', 80, 160, 55, CURRENT_TIMESTAMP - INTERVAL '3 hours'),
('domestic_waste', 'West Zone', 82, 165, 57, CURRENT_TIMESTAMP - INTERVAL '2 hours'),
('domestic_waste', 'West Zone', 78, 155, 53, CURRENT_TIMESTAMP - INTERVAL '1 hour'),
('domestic_waste', 'West Zone', 85, 170, 59, CURRENT_TIMESTAMP),

('domestic_waste', 'Central Zone', 110, 230, 78, CURRENT_TIMESTAMP - INTERVAL '3 hours'),
('domestic_waste', 'Central Zone', 112, 235, 80, CURRENT_TIMESTAMP - INTERVAL '2 hours'),
('domestic_waste', 'Central Zone', 108, 225, 76, CURRENT_TIMESTAMP - INTERVAL '1 hour'),
('domestic_waste', 'Central Zone', 115, 240, 82, CURRENT_TIMESTAMP);

-- Insert sample sensor data - Industrial Waste (Solid)
INSERT INTO sensor_data (
    sensor_type, 
    industry_name, 
    percentage, 
    tons, 
    timestamp
) VALUES 
('industrial_solid', 'Construction', 35, 1500, CURRENT_TIMESTAMP),
('industrial_solid', 'Mining', 25, 1200, CURRENT_TIMESTAMP),
('industrial_solid', 'Manufacturing', 20, 950, CURRENT_TIMESTAMP),
('industrial_solid', 'Food Processing', 12, 580, CURRENT_TIMESTAMP),
('industrial_solid', 'Others', 8, 380, CURRENT_TIMESTAMP);

-- Insert sample sensor data - Industrial Waste (Liquid)
INSERT INTO sensor_data (
    sensor_type, 
    industry_name, 
    percentage, 
    tons, 
    timestamp
) VALUES 
('industrial_liquid', 'Chemical Plants', 40, 8000, CURRENT_TIMESTAMP),
('industrial_liquid', 'Textile Mills', 28, 5600, CURRENT_TIMESTAMP),
('industrial_liquid', 'Paper Mills', 18, 3600, CURRENT_TIMESTAMP),
('industrial_liquid', 'Food Industries', 10, 2000, CURRENT_TIMESTAMP),
('industrial_liquid', 'Others', 4, 800, CURRENT_TIMESTAMP);

-- Insert sample sensor data - Industrial Waste (Air)
INSERT INTO sensor_data (
    sensor_type, 
    industry_name, 
    percentage, 
    tons, 
    timestamp
) VALUES 
('industrial_air', 'Power Plants', 45, 4500, CURRENT_TIMESTAMP),
('industrial_air', 'Steel Industry', 30, 3000, CURRENT_TIMESTAMP),
('industrial_air', 'Cement Plants', 18, 1800, CURRENT_TIMESTAMP),
('industrial_air', 'Chemical Plants', 5, 500, CURRENT_TIMESTAMP),
('industrial_air', 'Others', 2, 200, CURRENT_TIMESTAMP);

-- Insert sample sensor data - Pollution Zones (Pune)
INSERT INTO sensor_data (
    sensor_type,
    zone_id,
    zone_name,
    aqi_level,
    pm25,
    pm10,
    no2,
    so2,
    timestamp
) VALUES 
(
    'pollution_zone',
    'north-industrial',
    'North Industrial Zone',
    85,
    150,
    280,
    180,
    220,
    CURRENT_TIMESTAMP
),
(
    'pollution_zone',
    'east-residential',
    'East Residential Area',
    45,
    65,
    110,
    70,
    45,
    CURRENT_TIMESTAMP
),
(
    'pollution_zone',
    'south-commercial',
    'South Commercial Zone',
    60,
    95,
    165,
    120,
    85,
    CURRENT_TIMESTAMP
),
(
    'pollution_zone',
    'west-landfill',
    'West Landfill Area',
    75,
    120,
    220,
    140,
    160,
    CURRENT_TIMESTAMP
),
(
    'pollution_zone',
    'central-mixed',
    'Central Mixed Zone',
    55,
    80,
    140,
    100,
    70,
    CURRENT_TIMESTAMP
);
