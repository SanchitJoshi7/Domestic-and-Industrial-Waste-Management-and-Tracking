-- Alerts Table Schema
CREATE TABLE IF NOT EXISTS alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    authority_id VARCHAR(50) NOT NULL REFERENCES authorities(id) ON DELETE RESTRICT,
    alert_number VARCHAR(50) UNIQUE,
    
    -- Alert details
    message TEXT NOT NULL,
    address VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    
    -- Status tracking
    status VARCHAR(20) DEFAULT 'submitted',
    priority VARCHAR(10) DEFAULT 'medium',
    
    -- Additional info
    images_urls TEXT[],
    attachments TEXT[],
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    acknowledged_at TIMESTAMP,
    processing_started_at TIMESTAMP,
    resolved_at TIMESTAMP,
    
    -- Resolution details
    resolution_notes TEXT,
    resolved_by UUID REFERENCES users(id) ON DELETE SET NULL,
    
    -- Audit
    viewed_by_authority BOOLEAN DEFAULT FALSE,
    viewed_at TIMESTAMP,
    
    -- Constraints
    CONSTRAINT valid_status CHECK (status IN (
        'submitted', 'acknowledged', 'processing', 'resolved', 'rejected', 'archived'
    )),
    CONSTRAINT valid_priority CHECK (priority IN ('low', 'medium', 'high', 'critical')),
    CONSTRAINT valid_coordinates CHECK (
        (latitude IS NULL AND longitude IS NULL) OR
        (latitude IS NOT NULL AND longitude IS NOT NULL AND
         latitude >= -90 AND latitude <= 90 AND
         longitude >= -180 AND longitude <= 180)
    )
);

-- Create indexes
CREATE INDEX idx_alerts_user_id ON alerts(user_id);
CREATE INDEX idx_alerts_authority_id ON alerts(authority_id);
CREATE INDEX idx_alerts_status ON alerts(status);
CREATE INDEX idx_alerts_priority ON alerts(priority);
CREATE INDEX idx_alerts_created_at ON alerts(created_at DESC);
CREATE INDEX idx_alerts_resolved_at ON alerts(resolved_at);
CREATE INDEX idx_alerts_alert_number ON alerts(alert_number);

-- Composite indexes for common queries
CREATE INDEX idx_alerts_user_status ON alerts(user_id, status);
CREATE INDEX idx_alerts_authority_status ON alerts(authority_id, status);
CREATE INDEX idx_alerts_priority_status ON alerts(priority, status);

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION update_alerts_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER alerts_updated_at_trigger
BEFORE UPDATE ON alerts
FOR EACH ROW
EXECUTE FUNCTION update_alerts_updated_at();

-- Create trigger to auto-generate alert number
CREATE OR REPLACE FUNCTION generate_alert_number()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.alert_number IS NULL THEN
        NEW.alert_number := 'ALERT-' || TO_CHAR(CURRENT_DATE, 'YYYYMMDD') || '-' || 
                           LPAD(NEXTVAL('alert_number_seq')::TEXT, 5, '0');
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create sequence for alert numbers
CREATE SEQUENCE IF NOT EXISTS alert_number_seq START 1000;

CREATE TRIGGER alerts_number_trigger
BEFORE INSERT ON alerts
FOR EACH ROW
EXECUTE FUNCTION generate_alert_number();

-- Create trigger to set acknowledged_at timestamp
CREATE OR REPLACE FUNCTION set_alert_acknowledged()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'acknowledged' AND OLD.status != 'acknowledged' THEN
        NEW.acknowledged_at := CURRENT_TIMESTAMP;
    END IF;
    
    IF NEW.status = 'processing' AND OLD.status != 'processing' THEN
        NEW.processing_started_at := CURRENT_TIMESTAMP;
    END IF;
    
    IF NEW.status = 'resolved' AND OLD.status != 'resolved' THEN
        NEW.resolved_at := CURRENT_TIMESTAMP;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER alerts_timestamp_trigger
BEFORE UPDATE ON alerts
FOR EACH ROW
EXECUTE FUNCTION set_alert_acknowledged();
