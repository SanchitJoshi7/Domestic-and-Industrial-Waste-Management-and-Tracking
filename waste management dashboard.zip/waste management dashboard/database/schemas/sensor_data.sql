-- Updated Sensor Data Table Schema with District and Taluka
CREATE TABLE IF NOT EXISTS sensor_data (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sensor_type VARCHAR(50) NOT NULL,
    district VARCHAR(100),
    taluka VARCHAR(100),
    zone VARCHAR(100),
    zone_id VARCHAR(50),
    zone_name VARCHAR(100),
    
    -- Domestic waste parameters
    bod DECIMAL(10,2),
    cod DECIMAL(10,2),
    toc DECIMAL(10,2),
    
    -- Pollution parameters
    aqi_level INTEGER,
    pm25 DECIMAL(10,2),
    pm10 DECIMAL(10,2),
    no2 DECIMAL(10,2),
    so2 DECIMAL(10,2),
    
    -- Industrial parameters
    industry_name VARCHAR(100),
    percentage DECIMAL(10,2),
    tons DECIMAL(15,2),
    
    -- Metadata
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT valid_sensor_type CHECK (sensor_type IN (
        'domestic_waste', 'industrial_solid', 'industrial_liquid', 
        'industrial_air', 'pollution_zone'
    )),
    CONSTRAINT valid_aqi_level CHECK (aqi_level >= 0 AND aqi_level <= 500),
    CONSTRAINT valid_percentage CHECK (percentage >= 0 AND percentage <= 100)
);

-- Create indexes for faster queries
CREATE INDEX idx_sensor_data_sensor_type ON sensor_data(sensor_type);
CREATE INDEX idx_sensor_data_timestamp ON sensor_data(timestamp);
CREATE INDEX idx_sensor_data_district ON sensor_data(district);
CREATE INDEX idx_sensor_data_taluka ON sensor_data(taluka);
CREATE INDEX idx_sensor_data_zone ON sensor_data(zone);
CREATE INDEX idx_sensor_data_zone_id ON sensor_data(zone_id);
CREATE INDEX idx_sensor_data_created_at ON sensor_data(created_at);
CREATE INDEX idx_sensor_data_industry ON sensor_data(industry_name);

-- Create composite indexes for common queries
CREATE INDEX idx_sensor_data_district_taluka ON sensor_data(district, taluka, timestamp DESC);
CREATE INDEX idx_sensor_data_type_time ON sensor_data(sensor_type, timestamp DESC);

-- Create trigger to update updated_at
CREATE OR REPLACE FUNCTION update_sensor_data_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sensor_data_updated_at_trigger
BEFORE UPDATE ON sensor_data
FOR EACH ROW
EXECUTE FUNCTION update_sensor_data_updated_at();