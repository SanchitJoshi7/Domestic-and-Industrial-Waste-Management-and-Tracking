-- Authorities Table Schema
CREATE TABLE IF NOT EXISTS authorities (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(10),
    description TEXT,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    address TEXT,
    
    -- Jurisdiction
    jurisdiction VARCHAR(100),
    jurisdiction_type VARCHAR(50),
    
    -- Contact details
    primary_contact_name VARCHAR(100),
    primary_contact_email VARCHAR(100),
    primary_contact_phone VARCHAR(20),
    
    -- Authority metadata
    is_active BOOLEAN DEFAULT TRUE,
    response_sla_hours INTEGER DEFAULT 24,
    
    -- Website and social
    website VARCHAR(255),
    social_media JSONB,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT valid_jurisdiction_type CHECK (jurisdiction_type IN (
        'municipal', 'state', 'national', 'regional'
    )),
    CONSTRAINT email_format CHECK (email ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$')
);

-- Create indexes
CREATE INDEX idx_authorities_name ON authorities(name);
CREATE INDEX idx_authorities_jurisdiction ON authorities(jurisdiction);
CREATE INDEX idx_authorities_is_active ON authorities(is_active);
CREATE INDEX idx_authorities_email ON authorities(email);

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION update_authorities_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER authorities_updated_at_trigger
BEFORE UPDATE ON authorities
FOR EACH ROW
EXECUTE FUNCTION update_authorities_updated_at();
